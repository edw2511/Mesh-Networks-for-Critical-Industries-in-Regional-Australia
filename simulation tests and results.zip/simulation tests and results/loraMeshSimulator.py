import simpy
import random
import numpy as np
import math
import os
from inspect import currentframe
from collections import deque, defaultdict
import heapq
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import matplotlib.image as mpimg

# Simpy environment
env = simpy.Environment()

# Debug Mode
debug = 1
state_data_logging = False

# turn on/off graphics
graphics = 1
realtime_graphics = 1
fignum = 1
ROUTE_DIAGRAM_LIMIT = 75
slideShowPause = 0.001 #number of seconds to pause OR 0 to wait until key press

# do the full collision check
full_collision = True

#carrier sensing
carrier_sensing_ed = True
carrier_sensing_rp = True 

#global awareness, routing, sleep algorithms
positional_algo = True
standby_repeater_algo = True
energy_aware_algo = False
repeater_sleep_algo = True
repeater_synchronization_algo = False
wor_preamble_shrinking_algo = False

total_stanby = 0
standby_retains = 0
standby_recoveries = 0
repeater_role_changes = 0

# Averaege packet sending interval of end devices
avgSendTime = 600000 #in ms 
dataPacketsPerWor = 5 #number of sequential DATA packets sent after one ED WOR/ACK
repeatDelayMultiplier = 5 #mean repeater waiting period = airtime * repeatDelayMultiplier 

# THESIS: DATA_up opportunistic routing. WOR/CAD and DATA_down remain native.
OPPORTUNISTIC = True
OP_MAX_CANDIDATES = 3
OP_ETX_WEIGHT = 1.4
OP_HOP_WEIGHT = 1.0
OP_AIRTIME_WEIGHT = 0.025
OP_ENERGY_WEIGHT = 0.3
OP_WAKE_WEIGHT = 0.002
OP_RSSI_TRANSITION_DB = 6.0  # illustrative margin-to-success mapping
OP_HYSTERESIS = 0.12
OP_DWELL_MS = 120000.0
OP_GUARD_MS = 50.0
OP_JITTER_MS = 10.0
OP_TTL = 12
op_stats = defaultdict(int)
op_traces = defaultdict(list)

ROUTING_MODE = "opportunistic"

ROUTING_MODES = {
    "native",
    "flood",
    "shortest_hop",
    "weighted",
    "opportunistic"
}

OP_MAX_CANDIDATES = 3
OP_SUPPRESSION_ENABLED = True
LINK_EXTRA_LOSS_DB = {}
EXPERIMENT_EVENTS = []

def experiment_event(event, **kw):
    EXPERIMENT_EVENTS.append(dict(time_ms=float(env.now), event=event, **kw))

def extra_link_loss(a,b):
    return LINK_EXTRA_LOSS_DB.get((a,b),0.0)


# Optional thesis packet-route visualisation (does not affect routing).
SHOW_ROUTING_OVERLAY = True
visual_forward_parents = defaultdict(dict)
visual_gateway_parents = defaultdict(dict)
visual_candidates = defaultdict(dict)
visual_suppressed = defaultdict(set)
visual_delivered = set()
visual_events = defaultdict(list)
visual_artists = []

def visual_event(seqNr, event_type, **details):
    if True:  # Record events even with interactive graphics disabled.
        visual_events[seqNr].append({'time_ms': env.now, 'event': event_type, **details})


worPreambleDuration = 1030 #ms; margin above the 1000 ms CAD period
repeaterRxIdleTimeout = 20000 #ms; ACK wait + standby/forwarding time + margin

experiment = 1

def routing_mode():
    if ROUTING_MODE not in ROUTING_MODES:
        raise ValueError(
            f"Unsupported routing mode: {ROUTING_MODE}"
        )

    return ROUTING_MODE
OPPORTUNISTIC = ROUTING_MODE == "opportunistic"

# These are arrays with measured values for sensitivity
#---------------SF---125-----250-----500----(BW in kHz)
sf7  = np.array([7, -126.50,-124.25,-120.75])
sf8  = np.array([8, -127.25,-126.75,-124.00])
sf9  = np.array([9, -131.25,-128.25,-127.50])
sf10 = np.array([10,-132.75,-130.25,-128.75])
sf11 = np.array([11,-134.50,-132.75,-128.75])
sf12 = np.array([12,-134.50,-132.25,-132.25])

sensi = np.array([sf7,sf8,sf9,sf10,sf11,sf12])
sf = 7
bw = 125
bw_index = {125: 1, 250: 2, 500: 3}
minsensi = sensi[sf-7][bw_index[bw]] #if SF, BW unknown, use -112.0dB for minsensi

#Path loss function parameters
Ptx = 14
gamma = 2.08
d0 = 40.0
var = 0  # variance ignored for now
Lpld0 = 127.41
GL = 0
Lpl = Ptx - minsensi
maxDist = d0*(10**((Lpl-Lpld0)/(10.0*gamma))) #CORRECTED MISTAKE HERE: REPLACED 'e' with 10
print ("amin", minsensi, "Lpl", Lpl)
print ("maxDist:", maxDist)
xmax = 0
ymax = 0

#Graphic related variables
timePlot = None
txInfoPlot = None
transmittingNodeIDs = []
colInfoPlot = None

# prepare graphics and add sink
if (graphics == 1):
    plt.ion()
    plt.figure(figsize=(15.36, 7.52))
    ax = plt.gcf().gca()

# global value of packet sequence numbers
packetSeq = 0
totalSimPackets = 20
lastPacketGenTime = 0
generatedDataPacketCount = 0

# list of nodes
nodes = []
repeaterProcessingTime = 10
# maximum number of packets the node rx can receive at the same time
maxRxReceives = 8

# list of received packets (accounting reception at all the nodes)
collidedPackets=[]
lostPackets = []
#global packet seq numbers received at gateways
packetsRecBS = []
lastTimePacketRecBS = 0
dataPacketDiagnostics = {}
worPacketDiagnostics = {}
packetTransactionOverrides = {}
Q1_time = 0
Q2_time = 0
Q3_time = 0
predicted_DER = 1
packetLatencies = []

# WOR and CAD related
nodeClockAccuracy = 20 #ppm

# ----------------------------------------------------------------------------------
#COLLISION CHECK
# ----------------------------------------------------------------------------------
def checkcollision(packet, receiverNode):

    col = 0  #collision flag
    processing = 0

    for i in range(0,len(receiverNode.packetSourcesAtRx)):
        if receiverNode.packetSourcesAtRx[i].packet[receiverNode.id].processed == 1:
            processing = processing + 1
    if (processing >= maxRxReceives):
        print ("Too many packets at the receiver node. No of packets:", len(receiverNode.packetSourcesAtRx))
        packet.processed = 0
        return 1
    else:
        packet.processed = 1

    if(debug):
        print ("CHECK collision for packet-{} from node {} to node {} (sf:{} bw:{}kHz freq:{:.0f}MHz) No of other packets at rx: {}".format(
            packet.seqNr, packet.nodeid,receiverNode.id, packet.sf, packet.bw, packet.freq/10.0**6, len(receiverNode.packetSourcesAtRx)-1))

    #checking whether the receiving node has only one antenna, which is also in TX mode
    if(receiverNode.antennaType.lower() == "single" and receiverNode.tx_activity["active"]):
        packet.collided = 1
        packet.processed = 0
        col = 1
        if(debug and receiverNode.id!=packet.nodeid):
            print("   --collision since node",receiverNode.id,"is in transmitting state. Tx Acivity --> {", receiverNode.tx_activity["active"], receiverNode.tx_activity["start"], receiverNode.tx_activity["end"], receiverNode.tx_activity["preamble_duration"], receiverNode.tx_activity["tx_packet_type"],receiverNode.tx_activity["in_preamble"](env) ,"}")
        return col

    #checking packet collisions at receiving antenna
    elif receiverNode.packetSourcesAtRx:
        for other in receiverNode.packetSourcesAtRx:
            if other.id != packet.nodeid:
                if(debug): 
                    print (">> node {} (sf:{} bw:{}kHz freq:{:.0f}MHz)".format(
                        other.id, other.packet[receiverNode.id].sf, other.packet[receiverNode.id].bw, other.packet[receiverNode.id].freq/10.0**6))
                # simple collision
                if frequencyCollision(packet, other.packet[receiverNode.id]) \
                    and sfCollision(packet, other.packet[receiverNode.id]):
                    if full_collision:
                        if timingCollision(packet, other.packet[receiverNode.id]):
                            # check who collides in the power domain
                            c = powerCollision(packet, other.packet[receiverNode.id]) #returns a tuple of pwr collided packets
                            # 'c' may include either this packet, or the other packet, or both
                            for p in c:
                                p.collided = 1
                                if(p == packet):
                                    col = 1
                        else:
                            # no timing collision, all fine
                            pass
                    else:
                        packet.collided = 1
                        other.packet[receiverNode.id].collided = 1  # other packet also got collided, if it wasn't collided already
                        col = 1
        return col
    return 0


# frequencyCollision, conditions
#
#        |f1-f2| <= 120 kHz if f1 or f2 has bw 500
#        |f1-f2| <= 60 kHz if f1 or f2 has bw 250
#        |f1-f2| <= 30 kHz if f1 or f2 has bw 125
def frequencyCollision(p1,p2):
    # Frequencies are stored in Hz, while bandwidth values are in kHz.
    if (abs(p1.freq-p2.freq)<=120000 and (p1.bw==500 or p2.bw==500)):
        if(debug):
            print ("   --collision frequency at 500kHz bw")
        return True
    elif (abs(p1.freq-p2.freq)<=60000 and (p1.bw==250 or p2.bw==250)):
        if(debug):
            print ("   --collision frequency at 250kHz bw")
        return True
    elif (abs(p1.freq-p2.freq)<=30000):
        if(debug):
            print ("   --collision frequency at 125kHz bw")
        return True
    if(debug):
        print ("   --no frequency collision")
    return False


def sfCollision(p1, p2):
    if p1.sf == p2.sf:
        if(debug):
            print ("   --collision sf node {} and node {}".format(p1.nodeid, p2.nodeid))
        # p2 may have been lost too, will be marked by other checks
        return True
    if(debug):
        print ("   --no sf collision")
    return False


def powerCollision(p1, p2):
    powerThreshold = 3 # dB capture threshold
    if(debug):
        print ("   --pwr: node {0.nodeid} {0.rssi:3.2f} dBm node {1.nodeid} {1.rssi:3.2f} dBm; diff {2:3.2f} dBm".format(p1, p2, round(p1.rssi - p2.rssi,2)))
    if abs(p1.rssi - p2.rssi) < powerThreshold:
        if(debug):
            print ("   --collision pwr both node {} and node {}".format(p1.nodeid, p2.nodeid))
        # packets are too close to each other, both collide
        # return both packets as casualties
        return (p1, p2)
    elif p1.rssi - p2.rssi < powerThreshold:
        # p2 overpowered p1, return p1 as casualty
        if(debug):
            print ("   --collision pwr node {} overpowered node {}".format(p2.nodeid, p1.nodeid))
        return (p1,)
    if(debug):
        print ("   --p1 wins, p2 lost")
    # p2 was the weaker packet, return it as a casualty
    return (p2,)


def timingCollision(p1, p2):
    # assuming p1 is the freshly arrived packet and this is the last check
    # we've already determined that p1 is a weak packet, so the only
    # way we can win is by being late enough (only the first n - 5 preamble symbols overlap)

    # assuming 8 preamble symbols
    Npream = 8

    # we can lose at most (Npream - 5) * Tsym of our preamble
    Tpreamb = 2**p1.sf/(1.0*p1.bw) * (Npream - 5)

    # check whether p2 ends in p1's critical section
    p2_end = p2.addTime + p2.rectime
    p1_cs = env.now + Tpreamb
    if(debug):
        print ("   --collision timing node {} ({},{},{}) node {} ({},{})".format(
            p1.nodeid, env.now - env.now, p1_cs - env.now, p1.rectime,
            p2.nodeid, p2.addTime - env.now, p2_end - env.now
        ))
    if p1_cs < p2_end:
        # p1 collided with p2 and lost
        if(debug):
            print ("   --not late enough")
        return True
    if(debug):
        print ("   --saved by the preamble")
    return False


# this function computes the airtime of a packet
# according to LoraDesignGuide_STD.pdf
#
def airtime(sf,cr,pl,bw, premlen=8):
    H = 0        # implicit header disabled (H=0) or not (H=1)
    DE = 0       # low data rate optimization enabled (=1) or not (=0)

    if bw == 125 and sf in [11, 12]:
        # low data rate optimization mandated for BW125 with SF11 and SF12
        DE = 1
    if sf == 6:
        # can only have implicit header with SF6
        H = 1

    Tsym = (2.0**sf)/bw
    if(premlen == -1): #Default WOR preamble with CAD/clock-drift margin
        Tpream = worPreambleDuration
    else: 
        Tpream = (premlen + 4.25)*Tsym
    payloadSymbNB = 8 + max(math.ceil((8.0*pl-4.0*sf+28+16-20*H)/(4.0*(sf-2*DE)))*(cr+4),0)
    Tpayload = payloadSymbNB * Tsym
    return Tpream, Tpayload


def packetTransactionId(seqNr):
    """Return the stable source/sequence key shared by WOR and DATA packets."""
    sourceId, packetNumber, *_ = seqNr.split("|")
    logicalPacketId = f"{sourceId}|{packetNumber}"
    return packetTransactionOverrides.get(logicalPacketId, logicalPacketId)


# THESIS ROUTING: globally informed, weighted opportunistic forwarding.
# Uses physical node IDs (not Graph's compact repeater/gateway indices).
class OpportunisticRouter:
    def __init__(self):
        self.routes = {}
        self.last_switch = {}
        self.cached = {}
        self.cache_epoch = -1

    def gateways(self):
        return [n.id for n in nodes if n.type.lower() == 'gw']

    def link_probability(self, a, b):
        if a == b or nodes[a].type.lower() == 'gw' or not nodes[a].available or not nodes[b].available:
            return 0.0
        sender, receiver = nodes[a], nodes[b]
        # Estimate DATA_up link budget, not WOR packet budget. ED has half Ptx.
        distance = math.hypot(sender.x-receiver.x, sender.y-receiver.y)
        loss = Lpld0 + 10*gamma*math.log10(max(distance, 0.001)/d0) + extra_link_loss(a,b)
        power = Ptx/2 if sender.type.lower() == 'ed' else Ptx
        rssi = power - GL - loss
        threshold = float(minsensi)
        margin = max(-60.0, min(60.0, rssi-threshold))
        p = 1.0/(1.0+math.exp(-margin/OP_RSSI_TRANSITION_DB))
        return p if rssi >= threshold else 0.0

    def edge_cost(self, a, b):
        if nodes[b].type.lower() not in ('rp','gw'):
            return math.inf
        p = self.link_probability(a,b)
        if p <= 0:
            return math.inf
        sender, receiver = nodes[a], nodes[b]
        # The simulator's default DATA payload and LoRa PHY configuration.
        airtime_ms = sum(airtime(sf, 2, 20, bw))
        energy = 0.0 if receiver.type.lower() == 'gw' else (100.0/max(1.0,receiver.batteryPercentage)-1.0)
        # Expected availability penalty: sleep and CAD are not equivalent to RX.
        wake_ms = (receiver.cadPeriodity/2.0 if receiver.mode in ('SLEEP','CAD') else 0.0)
        return (OP_HOP_WEIGHT + OP_ETX_WEIGHT/p +
                OP_AIRTIME_WEIGHT*airtime_ms/p + OP_ENERGY_WEIGHT*energy +
                OP_WAKE_WEIGHT*wake_ms)

    def downstream(self, gateway):
        # Reverse Dijkstra over the directed DATA_up links.
        distances = {gateway: 0.0}
        queue = [(0.0,gateway)]
        while queue:
            cost, at = heapq.heappop(queue)
            if cost > distances[at] + 1e-9:
                continue
            for n in nodes:
                if n.id == at or n.type.lower() not in ('ed','rp'):
                    continue
                edge = self.edge_cost(n.id,at)
                if math.isfinite(edge) and cost+edge < distances.get(n.id,math.inf):
                    distances[n.id] = cost+edge
                    heapq.heappush(queue,(cost+edge,n.id))
        return distances

    def best_path(self, source, gateway):
        downstream = self.downstream(gateway)
        if source not in downstream:
            return []
        path, seen = [source], {source}
        while path[-1] != gateway and len(path) <= len(nodes):
            at = path[-1]
            options = [(self.edge_cost(at,n.id)+downstream.get(n.id,math.inf),n.id)
                       for n in nodes if n.id not in seen and
                       (n.type.lower() == 'rp' or n.id == gateway) and
                       math.isfinite(self.edge_cost(at,n.id))]
            if not options:
                return []
            _, nxt = min(options)
            if downstream.get(nxt,math.inf) >= downstream.get(at,math.inf):
                return []
            path.append(nxt)
            seen.add(nxt)
        return path if path[-1] == gateway else []

    def path_cost(self, path):
        return sum(self.edge_cost(a,b) for a,b in zip(path,path[1:])) if path else math.inf

    def choose_path(self, source, gateway, now):
        proposed = self.best_path(source,gateway)
        previous = self.routes.get(source,[])
        old_cost = self.path_cost(previous)
        new_cost = self.path_cost(proposed)
        if not previous or not math.isfinite(old_cost):
            if previous and proposed != previous:
                op_stats['forced_handovers'] += 1
            self.routes[source] = proposed
            self.last_switch[source] = now
            if previous != proposed: experiment_event("route_change", source=source, old_route=str(previous), new_route=str(proposed))
        elif (proposed and proposed != previous and
              now-self.last_switch.get(source,-math.inf) >= OP_DWELL_MS and
              new_cost < (1-OP_HYSTERESIS)*old_cost):
            self.routes[source] = proposed
            self.last_switch[source] = now
            if previous != proposed: experiment_event("route_change", source=source, old_route=str(previous), new_route=str(proposed))
            op_stats['handovers'] += 1
        return self.routes.get(source,[])

    def candidates(self, sender, origin, gateway):
        downstream = self.downstream(gateway)
        here = downstream.get(sender,math.inf)
        path = self.routes.get(origin,[])
        preferred = None
        if sender in path and path.index(sender)+1 < len(path):
            preferred = path[path.index(sender)+1]
        options = [n.id for n in nodes if n.id != sender and
                   (n.type.lower() == 'rp' or n.id == gateway) and
                   math.isfinite(self.edge_cost(sender,n.id)) and
                   downstream.get(n.id,math.inf) < here]
        options.sort(key=lambda nid: (nid != preferred,
                     self.edge_cost(sender,nid)+downstream[nid],nid))
        return options[:OP_MAX_CANDIDATES]

    def all_routes(self, source, gateway, limit=10000):
        routes = []
        def walk(at, path):
            if len(routes) >= limit:
                return
            if at == gateway:
                routes.append(path)
                return
            for n in nodes:
                if (n.id not in path and (n.type.lower() == 'rp' or n.id == gateway) and
                    math.isfinite(self.edge_cost(at,n.id))):
                    walk(n.id,path+[n.id])
        walk(source,[source])
        return sorted(routes,key=self.path_cost)

    def shortest_hop_path(self, source, gateway):
        from collections import deque
        q=deque([[source]])
        seen={source}
        while q:
            path=q.popleft()
            at=path[-1]
            if at==gateway: return path
            for candidate in nodes:
                nxt=candidate.id
                if nxt in seen or candidate.type.lower() not in ("rp","gw"): continue
                if not math.isfinite(self.hop_edge_cost(at,nxt)): continue
                seen.add(nxt)
                q.append(path+[nxt])
        return []

    def hop_edge_cost(self, a, b):
        if not nodes[a].available or not nodes[b].available:
            return math.inf

        if self.link_probability(a, b) <= 0:
            return math.inf

        return 1.0

router = OpportunisticRouter()

def refresh_mobile_links(moving_node_id=None):
    # Recompute cached RF topology without appending duplicate neighbour indices.
    for n in nodes:
        n.dist = [math.hypot(n.x-r.x,n.y-r.y) for r in nodes]
        n.neighbor_ids = [r.id for r in nodes if r.id != n.id and
                          n.type.lower() != 'ed' and r.type.lower() != 'ed' and
                          n.dist[r.id] <= maxDist]
        n.neighbor_rssi = [n.calc_rssi(r.id) if r.id in n.neighbor_ids else 0.0
                           for r in nodes]
        for pk in n.packet:
            if pk.rxNodeId == n.id:
                continue
            d = n.dist[pk.rxNodeId]
            pathloss = Lpld0+10*gamma*math.log10(max(d,0.001)/d0)
            pk.rssi = pk.ptx-GL-pathloss-extra_link_loss(n.id,pk.rxNodeId)
            threshold = float(sensi[pk.sf-7][bw_index[pk.bw]])
            pk.lost = pk.rssi < threshold
    if moving_node_id is not None:
        op_stats['topology_refreshes'] += 1
        if nodes[moving_node_id].type.lower() == 'ed' and router.gateways():
            router.choose_path(moving_node_id,router.gateways()[0],env.now)
    # Recompute the native position-learning tree only when explicitly requested.
    # Its compact-index handling needs correction before invoking on arbitrary node order.

#FUNCTIONS FOR POSITION LEARNING ALGORITHM
def estimate_dist_from_rssi(rssi):
    global Ptx
    global gamma
    global d0
    global Lpld0
    global GL
    Lpl = Ptx -GL -rssi
    d = pow(10,(Lpl -Lpld0)/(10*gamma))*d0
    return d


def run_position_learning():
    """Native distance-oriented routing, corrected to use physical node IDs.

    This is retained for WOR/CAD and baseline operation. Opportunistic DATA_up
    uses its separate weighted router; the two are deliberately not conflated.
    """
    infrastructure = [n for n in nodes if n.type.lower() in ('rp','gw')]
    if not infrastructure:
        return
    ids = [n.id for n in infrastructure]
    adjacency = {nid: [] for nid in ids}
    for n in infrastructure:
        for other in infrastructure:
            if other.id == n.id:
                continue
            distance = math.hypot(n.x-other.x,n.y-other.y)
            if distance <= maxDist:
                adjacency[n.id].append((other.id,distance))
    gateways = [n.id for n in infrastructure if n.type.lower() == 'gw']
    best = {nid: math.inf for nid in ids}
    next_hop = {nid: -1 for nid in ids}
    nearest = {nid: -1 for nid in ids}
    q = []
    for gateway in gateways:
        best[gateway] = 0.0
        next_hop[gateway] = gateway
        nearest[gateway] = gateway
        heapq.heappush(q,(0.0,gateway))
    while q:
        cost, at = heapq.heappop(q)
        if cost > best[at]+1e-9:
            continue
        for prev, length in adjacency[at]:
            proposed = cost+length
            if proposed < best[prev]-1e-9:
                best[prev] = proposed
                next_hop[prev] = at
                nearest[prev] = nearest[at]
                heapq.heappush(q,(proposed,prev))
    for n in infrastructure:
        n.distanceValue = best[n.id]
        n.nextRp = next_hop[n.id]
        n.nextRpOriginal = next_hop[n.id]
        n.nearestGwId = nearest[n.id]
    for n in infrastructure:
        if n.type.lower() != 'rp':
            continue
        hops, current, seen = 0,n.id,set()
        while current not in gateways and current not in seen:
            seen.add(current)
            nxt = next_hop.get(current,-1)
            if nxt < 0:
                break
            current = nxt
            hops += 1
        n.syncLevel = hops
        n.worUpPacketHistory = deque([0]*(hops+2),maxlen=hops+2)


#debugging function to get current line number
def get_linenumber():
    cf = currentframe()
    return cf.f_back.f_lineno


#
# This is called to configure the network after creating all nodes
#
def networkConfig():
    global nodes
    for i in range(len(nodes)):
        nodes[i].createPackets()
        # if(realtime_graphics == 1 and graphics == 1):
        nodes[i].txArrowPlots = [None] * len(nodes)

    run_position_learning()
    
    #Graphic Config
    if(graphics):
        global xmax
        global ymax
        for i in range(len(nodes)):
            if(nodes[i].x > xmax):
                xmax = nodes[i].x
            if(nodes[i].y > ymax):
                ymax = nodes[i].y
        xmax = xmax*1.1
        ymax = ymax*1.1
        
        ax.add_patch(Rectangle((0, 0), xmax, ymax, fill=None, alpha=1))
        current_script_path = os.path.abspath(__file__)
        current_script_directory = os.path.dirname(current_script_path)
        legend_path = os.path.join(current_script_directory, 'simulatorLegend.png')
        if os.path.isfile(legend_path):
            legendImg = mpimg.imread(legend_path)
            ax.imshow(legendImg, extent=(xmax*0.01, xmax*0.25, ymax*0.01, ymax*0.32), aspect='auto')
        else:
            ax.text(.01,.01,'Blue dashed: selected route\nGreen: forwarding attempts\nBlack/grey: radio TX\nRed: collision',
                    transform=ax.transAxes, fontsize=8, va='bottom',
                    bbox={'facecolor':'white','alpha':.85})


# ----------------------------------------------------------------------------------
# Python classes
# ----------------------------------------------------------------------------------

#
# this class creates a node
#
def clear_routing_overlay():
    for artist in visual_artists:
        try:
            artist.remove()
        except (ValueError, NotImplementedError):
            pass
    visual_artists.clear()


def reconstruct_packet_path(seqNr, gateway_id=None):
    source = int(seqNr.split('|', 1)[0])
    parents = visual_forward_parents.get(seqNr, {})
    if gateway_id is not None:
        final = visual_gateway_parents.get(seqNr, {}).get(gateway_id)
        if final is not None:
            path = [gateway_id, final]
            current, seen = final, set(path)
            while current != source:
                previous = parents.get(current)
                if previous is None or previous in seen:
                    break
                path.append(previous)
                seen.add(previous)
                current = previous
            return list(reversed(path))
    if not parents:
        return [source]
    current = next(reversed(parents))
    path, seen = [current], {current}
    while current != source:
        previous = parents.get(current)
        if previous is None or previous in seen:
            break
        path.append(previous)
        seen.add(previous)
        current = previous
    return list(reversed(path))


def draw_routing_overlay(seqNr):
    if not (graphics and SHOW_ROUTING_OVERLAY):
        return
    clear_routing_overlay()
    source = int(seqNr.split('|', 1)[0])
    gateways = router.gateways()
    if not gateways:
        return
    gateway = gateways[0]
    selected = router.routes.get(source, [])
    actual = reconstruct_packet_path(seqNr, gateway if seqNr in visual_delivered else None)
    # Draw chosen route in blue; actual forwarding branch in green.
    for a, b in zip(selected, selected[1:]):
        line, = ax.plot([nodes[a].x, nodes[b].x], [nodes[a].y, nodes[b].y],
                        color='royalblue', linestyle='--', linewidth=2.8,
                        alpha=0.85, zorder=4)
        visual_artists.append(line)
    for a, b in zip(actual, actual[1:]):
        line, = ax.plot([nodes[a].x, nodes[b].x], [nodes[a].y, nodes[b].y],
                        color='limegreen', linewidth=4.5, alpha=0.85, zorder=5)
        visual_artists.append(line)
    for nid, info in visual_candidates.get(seqNr, {}).items():
        if info.get('status') != 'pending':
            continue
        n = nodes[nid]
        ring = plt.Circle((n.x, n.y), radius=9, fill=False,
                          edgecolor='darkorange', linewidth=2.5, zorder=7)
        ax.add_patch(ring)
        visual_artists.append(ring)
        visual_artists.append(ax.text(n.x+9, n.y+8, f"C{info['rank']+1}",
                                      color='darkorange', fontsize=10,
                                      fontweight='bold', zorder=8))
    for nid in visual_suppressed.get(seqNr, set()):
        n = nodes[nid]
        marker, = ax.plot(n.x, n.y, marker='x', markersize=13,
                          markeredgewidth=2.5, color='purple',
                          linestyle='None', zorder=9)
        visual_artists.append(marker)
    route_text = ' -> '.join(map(str, selected)) if selected else 'No route'
    actual_text = ' -> '.join(map(str, actual))
    status = 'DELIVERED' if seqNr in visual_delivered else 'IN PROGRESS'
    info_text = (f'Packet: {seqNr}\nStatus: {status}\n'
                 f'Selected: {route_text}\nObserved: {actual_text}\n'
                 f'Suppressed: {sorted(visual_suppressed.get(seqNr, set()))}')
    panel = ax.text(0.02, 0.73, info_text, transform=ax.transAxes,
                    fontsize=9, va='top', family='monospace',
                    bbox={'boxstyle':'round,pad=0.5', 'facecolor':'white',
                          'edgecolor':'gray', 'alpha':0.9}, zorder=20)
    visual_artists.append(panel)
    from matplotlib.lines import Line2D
    old_legend = ax.get_legend()
    handles = [
        Line2D([0],[0],color='royalblue',linestyle='--',lw=2.8,label='Calculated route'),
        Line2D([0],[0],color='limegreen',lw=4,label='Forwarding attempts'),
        Line2D([0],[0],color='darkorange',marker='o',markerfacecolor='none',
               linestyle='None',markersize=9,label='Pending candidate'),
        Line2D([0],[0],color='purple',marker='x',linestyle='None',
               markersize=9,label='Suppressed candidate')]
    legend = ax.legend(handles=handles, loc='lower right', fontsize=8, framealpha=0.9)
    visual_artists.append(legend)
    if old_legend is not None:
        ax.add_artist(old_legend)
        # Track the original legend only if it was not already tracked.
        # Do not remove the original legend when clearing overlays.


class node():
    def __init__(self, env, x, y, type):
        global nodes
        nodes.append(self)
        self.id = len(nodes)-1
        self.x = x
        self.y = y
        self.type = type #3 TYPES: end device(ed), repeater(rp), gateway(gw)
        self.mode = "RX" #Can be "SLEEP", "CAD", "RX", "TX"
        self.lastStateChangeTime = 0

        #position and routing info
        self.distanceValue = -1
        self.nextRp = -1
        self.nextRpOriginal = -1
        self.neighbor_ids = []
        self.neighbor_rssi = []

        #Tx antenna state
        self.tx_activity = {
            "active": False,
            "start": None,
            "end": None,
            "preamble_duration": None,
            "tx_packet_type": "OTHER",  # Can be "WOR_up", "WOR_down", "DATA_up", "DATA_down", "OTHER"
            "in_preamble": lambda env: self.tx_activity["start"] is not None and self.tx_activity["start"] <= env.now < self.tx_activity["start"] + self.tx_activity["preamble_duration"]
        }

        #Power Consumption
        #------------------------------
        # Let's assume we are using a repeater made with 3 of RAK3172 modules
        # --> 1st one acting as the master, listening on RP Data channel, transmitting on all channels
        # --> 2nd one acting as a slave, listening on ED Data channel
        # --> 3rd one acting as a slave, listening on WOR channel
        #
        # Power consumptions calculated using RAK3172 datasheet:
        # TX Mode   : ~100mA + 5mA*2 = 110 mA (1 module in TX mode, other 2 active) 
        # RX Mode   : ~5 mA*3 = 15mA (3 modules in RX mode)
        # Sleep Mode: ~1.69 µA*3 = 5 µA (3 modules in Sleep mode)
        # CAD Mode  : (2*1.69*1000ms + 1.69*998ms + 5220*2ms)/1000ms = ~15uA (2 modules in sleep, 1 in CAD mode)
        #------------------------------
        self.batteryCapacity  = 100 #mAh
        self.batteryRemaining = 100 #mAh
        self.batteryPercentage = 100
        self.batteryDischargeRate = 1 #mA
        self.batteryLastRecordedTime = 0
        self.txPowerConsumption = 0
        self.rxPowerConsumption = 0
        self.cadPowerConsumption = 0
        self.currentRx = 15 #mA 
        self.currentTx = 110 #mA 
        self.currentCad = 0.015 #15uA in average
        self.cadPeriodity = 1000 #in ms

        # properties common for all types
        self.antennaType = "dual"  #single/dual
        self.packetSourcesAtRx = []
        self.recPackets = []
        # Reception alone does not make a DATA packet a duplicate. A repeater
        # may first overhear a packet without being selected to forward or
        # retain it, then later receive a copy for which it is a valid standby
        # or next-hop repeater.
        self.available = True
        self.handledDataPackets = set()
        self.opPending = {}   # DATA seqNr -> priority timer and cancellation state
        self.opForwarded = set()
        self.sensorSamples = []
        self.txPackets = []
        self.packet = []
        self.dist = []
        self.txArrowPlots = []

        #properties specific to end-devices
        self.sent = 0
        self.sentSuccessful = 0
        self.period = avgSendTime

        #properties specific to repeaters
        self.packetsFifo = simpy.Store(env)
        self.nTransmitters = simpy.Resource(env, capacity=1)
        self.tx_activity["active"] = False
        self.standbyBufferCount = 0
        self.activeReceiveProcesses = 0
        self.rxIdleDeadline = 0
        self.lowerDistanceRecBuffer = []
        self.txTimePercentage = 0
        self.nearestGwId = -1

        # WOR and CAD related
        self.lastCadScanTime = 0
        # Diagnostic state: CAD is a SimPy process, not just the value in mode.
        self.cadProcessActive = False
        self.cadExitTime = None
        self.cadExitReason = None
        global nodeClockAccuracy
        self.clockAccuracy = random.uniform(-nodeClockAccuracy,nodeClockAccuracy)/1000000
        self.worAckReceived = -1    # -1 means not expecting ack, 0 means expecting ack, 1 means ack received
        self.awaitingToSendWorAck = 0 #by Rp to ED
        self.toWhichEdAmIAwaitingToSendAck = [] #list of ED IDs
        self.pendingWorAckTransaction = None
        self.pendingWorAckCandidates = set()
        self.worAckStateByTransaction = {}
        self.pendingEdWorAcks = {}

        #Symchronization related
        self.cadTimingAdjustment = 0
        self.driftError = 1000 #in ms
        self.syncLevel = 0
        self.worUpPacketHistory = None

        #data dump files
        tx_status_file_name = 'tx status data/dump_node_'+ str(self.id)+'.txt'       
        self.tx_status_file = open(tx_status_file_name, 'w')
        # self.tx_status_file.write("initiated file for node"+str(self.id))
        
        battery_status_file_name = 'battery status data/dump_node_'+ str(self.id)+'.csv'       
        self.battery_status_file = open(battery_status_file_name, 'w')
        # self.battery_status_file.write("initiated file for node"+str(self.id)+"\n")
        self.battery_status_file.write(f"{self.id},{env.now},{self.batteryRemaining},{round(self.batteryPercentage,2)}\n")

        #wor preamble time data files
        wor_data_file_name = 'wor preamble data/dump_node_'+ str(self.id)+'.txt'       
        self.wor_data_file = open(wor_data_file_name, 'w')

        # State diagram data file
        state_diagram_file_name = 'state diagram data/dump_node_'+ str(self.id)+'.txt'       
        self.state_diagram_file = open(state_diagram_file_name, 'w')
        if(state_data_logging):
            self.state_diagram_file.write(f"{env.now} {self.mode}\n")

        # graphics for node
        global graphics
        if (graphics == 1):
            global ax
            if  (self.type.lower() == "ed"):
                self.icon = ax.add_artist(plt.Circle((self.x, self.y), 2, fill=True, color='blue'))
                self.label = ax.add_artist(plt.text(self.x+6,self.y,self.id, color='#888888'))
            elif(self.type.lower() == "rp"):
                self.icon = ax.add_artist(plt.Circle((self.x, self.y), 4, fill=True, color='green'))
                self.label = ax.add_artist(plt.text(self.x+6,self.y,self.id))
            elif(self.type.lower() == "gw"):
                self.icon = ax.add_artist(plt.Circle((self.x, self.y), 4, fill=True, color='red'))
                self.label = ax.add_artist(plt.text(self.x+6,self.y,self.id))
            else:
                print("Incorrect device type!")

    def setIconColorByMode(self, env, lineNo = 0):
        global graphics
        global state_data_logging

        # State timing is simulation logic and must not depend on plot rendering.
        self.lastStateChangeTime = env.now

        if(state_data_logging):
            # Record state change in state diagram file
            if self.mode == "TX":
                # For TX mode, write both preamble and frame timing
                self.state_diagram_file.write(f"{env.now} TX_preamble\n")
                self.state_diagram_file.write(f"{env.now + self.tx_activity['preamble_duration']} TX_frame\n")
            else:
                # For all other modes, write single state
                self.state_diagram_file.write(f"{env.now} {self.mode}\n")
            self.state_diagram_file.flush()  # Ensure writing to disk immediately
        
        if (graphics == 1):
            if (self.mode == "CAD" or self.mode == "SLEEP"):
                if self.type.lower() == "ed":
                    color = 'lightblue'
                elif self.type.lower() == "rp":
                    color = 'lightgreen'
                elif self.type.lower() == "gw":
                    color = 'pink'
            else:
                if self.type.lower() == "ed":
                    color = 'blue'
                elif self.type.lower() == "rp":
                    color = 'green'
                elif self.type.lower() == "gw":
                    color = 'red'
            if(color != self.icon.get_facecolor()):
                if(debug):
                    print(f"Node {self.id} changing color to {color} at line {lineNo}")
            self.icon.set_color(color)


    def batteryUpdate(self, env, dischargeRate):
        T = (env.now - self.batteryLastRecordedTime)/3600000
        self.batteryRemaining = self.batteryRemaining - T*self.batteryDischargeRate
        self.batteryPercentage = 100*self.batteryRemaining/self.batteryCapacity
        self.battery_status_file.write(f"{self.id},{env.now},{self.batteryRemaining},{round(self.batteryPercentage,2)}\n")
        self.batteryLastRecordedTime = env.now

        if(self.batteryDischargeRate==self.currentTx):
            self.txPowerConsumption += T*self.batteryDischargeRate
        elif(self.batteryDischargeRate==self.currentRx):
            self.rxPowerConsumption += T*self.batteryDischargeRate
        elif(self.batteryDischargeRate==self.currentCad):
            self.cadPowerConsumption += T*self.batteryDischargeRate

        self.batteryDischargeRate = dischargeRate
        

    def calc_rssi(self, otherNodeID):
        global Ptx
        global gamma
        global d0
        global Lpld0
        global GL
        d = self.dist[otherNodeID]
        if(d != 0):
            Lpl = Lpld0 + 10*gamma*math.log10(d/d0)
        else:
            Lpl = 0
        rssi = Ptx - GL - Lpl
        return rssi + random.uniform(-1, 1) #random noise added


    def canReceivePacket(self):
        if not self.available: return False
        """Return whether a receive antenna is available for packet delivery."""
        return self.mode == "RX" or (
            self.antennaType.lower() == "dual" and self.tx_activity["active"]
        )

    def extendRxIdleDeadline(self, env):
        """Keep a repeater awake long enough for the current protocol exchange."""
        global repeaterRxIdleTimeout
        if self.type.lower() == "rp":
            self.rxIdleDeadline = max(
                self.rxIdleDeadline,
                env.now + repeaterRxIdleTimeout,
            )

    def repeaterHasPendingWork(self):
        """Return whether sleeping could interrupt an active receive/forward flow."""
        if OPPORTUNISTIC and self.opPending:
            return True
        return (
            self.activeReceiveProcesses > 0
            or len(self.packetSourcesAtRx) > 0
            or self.standbyBufferCount > 0
            or len(self.packetsFifo.items) > 0
            or self.nTransmitters.count > 0
            or len(self.nTransmitters.queue) > 0
            or len(self.pendingEdWorAcks) > 0
        )

    def syncPendingEdWorAckState(self):
        """Maintain legacy summary fields from transaction-specific ACK state."""
        self.awaitingToSendWorAck = int(bool(self.pendingEdWorAcks))
        self.toWhichEdAmIAwaitingToSendAck = list(
            self.pendingEdWorAcks.values()
        )


    def createPackets(self, packetType = "OTHER", premlen=8, intendedRxId=-1, nodeAcknowledged=-1, seqNr=None, addTime=None):
        global experiment
        global bw
        global Ptx
        global minsensi
        global maxDist

        self.neighbor_rssi = [0 for x in range(len(nodes))]
        self.neighbor_ids = []
        self.dist = []

        # determining distances to RX nodes
        for i in range(0,len(nodes)):
            d = np.sqrt((self.x-nodes[i].x)*(self.x-nodes[i].x)+(self.y-nodes[i].y)*(self.y-nodes[i].y))
            # d = abs(self.x-nodes[i].x) + abs((self.y-nodes[i].y))
            self.dist.append(d)

            if(d<= maxDist and self.type != "ed" and nodes[i].type != "ed" and i != self.id):
                self.neighbor_rssi[i] = self.calc_rssi(i)
                self.neighbor_ids.append(i)

        # if(debug):
        #     print(self.type.upper(),":",self.id, "x", self.x, "y", self.y, "dist: ", self.dist)


        #cr =1,2,3,or 4
        #cr = 1 corresponds to coding rate 4/5 and cr=4 corresponds to coding rate 4/8
        # 4/8 coding rate means that for every 4 bits of useful information the coder generates 8bits of data including error correction bits
        # determining tx LoRa params  
        if(experiment == 1):     
            sf = 7
            cr = 2
            freq = 915900000 # Data channel for repeaters
            if (self.type.lower() == "ed"):
                freq = 917500000 #Data channel for end devices
            if ((packetType == "WOR_up" or packetType == "WOR_down")and self.type.lower() == "ed"):
                freq = 916200000 #WOR channel
            if ((packetType == "WOR_up" or packetType == "WOR_down")and self.type.lower() != "ed"):
                freq = 916500000 #WOR channel            

        # Here more experiments with different parameters can be added
        # ...
   
        # create virtual packets for each other node
        self.packet = []
        if(packetType == "WOR_up" or packetType == "WOR_down"):
            for i in range(0,len(nodes)):
                if(self.type.upper() == "ED"):
                    self.packet.append(myPacket(self.id, 15, self.dist[i], i, Ptx/2, sf, cr, bw, freq, packetType, premlen, intendedRxId, nodeAcknowledged, seqNr, addTime))
                else:
                    self.packet.append(myPacket(self.id, 15, self.dist[i], i, Ptx, sf, cr, bw, freq, packetType, premlen, intendedRxId, nodeAcknowledged, seqNr, addTime))
        else:
            for i in range(0,len(nodes)):
                if(self.type.upper() == "ED"):
                    self.packet.append(myPacket(self.id, 20, self.dist[i], i, Ptx/2, sf, cr, bw, freq, packetType, premlen, intendedRxId, nodeAcknowledged, seqNr, addTime))
                else:
                    self.packet.append(myPacket(self.id, 20, self.dist[i], i, Ptx, sf, cr, bw, freq, packetType, premlen, intendedRxId, nodeAcknowledged, seqNr, addTime))


    def drawTxArrows(self):
        for i in range(len(self.packet)):
            pk = self.packet[i]
            if(pk.lost == False):
                x = nodes[pk.nodeid].x
                y = nodes[pk.nodeid].y
                dx = nodes[pk.rxNodeId].x -x
                dy = nodes[pk.rxNodeId].y -y
                if(pk.packetType == "WOR_up" or pk.packetType == "WOR_down"):
                        self.txArrowPlots[i] = plt.arrow(x,y,dx,dy, width=1, color="lightblue", head_width=5, length_includes_head=True)
                elif(nodes[pk.rxNodeId].type.upper() == "ED"):
                    self.txArrowPlots[i] = plt.arrow(x,y,dx,dy, width=1, color="gray", head_width=5, length_includes_head=True)
                else:
                    self.txArrowPlots[i] = plt.arrow(x,y,dx,dy, width=1, color="black", head_width=5, length_includes_head=True, linewidth=2)


    def eraseTxArrows(self):
        for i in range(len(self.txArrowPlots)):
            if(self.txArrowPlots[i] != None):
                self.txArrowPlots[i].remove()
                self.txArrowPlots[i] = None


    def markCollidedArrows(self):
        for i in range(len(self.packet)):
            if(self.packet[i].lost == False):
                for node in nodes[i].packetSourcesAtRx:
                    if(node.packet[i].collided == True):
                        node.txArrowPlots[i].set_color("red")


    def drawTime(self, env):
        T = int(env.now)
        seconds = T // 1000
        minutes = seconds // 60
        hours = minutes // 60
        seconds %= 60
        minutes %= 60
        hours %= 24
        timeString = f"T= {hours:02d}:{minutes:02d}:{seconds:02d}"
        global timePlot
        global xmax
        global ymax
        if(timePlot != None):
            timePlot.remove()
        timePlot = plt.text(xmax*0.03, ymax*0.95, timeString, fontsize='large', verticalalignment='top')


    def drawTransmittingInfo(self):
        global txInfoPlot
        global transmittingNodeIDs
        global nodes
        global xmax
        global ymax
        if(self.id not in transmittingNodeIDs and self.tx_activity["active"]):
            transmittingNodeIDs.append(self.id)
        transmittingNodeIDsTemp = transmittingNodeIDs.copy()
        txInfoString = ""
        for i in range(len(transmittingNodeIDsTemp)):
            if(nodes[transmittingNodeIDsTemp[i]].tx_activity["active"]):
                x,y,t,pktType = nodes[transmittingNodeIDsTemp[i]].packet[0].seqNr.split('|')
                txInfoString += f"Node {transmittingNodeIDsTemp[i]} sending pkt {x}|{y}|{pktType}\n"
            else:
                transmittingNodeIDs.remove(transmittingNodeIDsTemp[i])
        if(txInfoPlot != None):
            txInfoPlot.remove()
        txInfoPlot = plt.text(xmax*0.33, ymax*0.95, txInfoString, fontsize='large', verticalalignment='top')


    def drawCollisionInfo(self):
        global colInfoPlot
        # global colPktObjects
        global transmittingNodeIDs
        global nodes
        global xmax
        global ymax
        if(self.id not in transmittingNodeIDs and self.tx_activity["active"]):
            transmittingNodeIDs.append(self.id)
        
        colPktObjects = []
        for i in range(len(transmittingNodeIDs)):
            if(nodes[transmittingNodeIDs[i]].tx_activity["active"]):
                for j in range(len(nodes)):
                    pk = nodes[transmittingNodeIDs[i]].packet[j]
                    if(pk.lost == False and pk.collided == True):
                        if(pk not in colPktObjects):
                            colPktObjects.append(pk)
                    else:
                        if(pk in colPktObjects):
                            colPktObjects.remove(pk)

        colInfoString = ""
        for pk in colPktObjects:
            if(pk.nodeid != pk.rxNodeId):
                colInfoString += f"Node {pk.nodeid} to Node {pk.rxNodeId} transmission collided\n"

        if(colInfoPlot != None):
            colInfoPlot.remove()
        colInfoPlot = plt.text(xmax*0.66, ymax*0.95, colInfoString, fontsize='large', verticalalignment='top')
    

    def endDeviceStateMachine(self, env):
        global packetSeq
        global lastPacketGenTime
        global generatedDataPacketCount
        global totalSimPackets
        global dataPacketsPerWor
        global packetTransactionOverrides
        global nodes

        while(True):
            self.mode = "CAD"
            self.batteryUpdate(env, self.currentCad)
            self.setIconColorByMode(env, get_linenumber())
            yield env.timeout(random.expovariate(1.0/float(self.period)))

            if packetSeq >= totalSimPackets:
                if(debug):
                    print(
                        f"[BURST_ALLOCATION_DONE] T={env.now:.2f} ED={self.id} "
                        f"packetSeq={packetSeq} totalSimPackets={totalSimPackets}"
                    )
                break

            # Reserve the complete burst before yielding so concurrent ED
            # processes cannot allocate duplicate sequence numbers.  A final
            # partial burst stops exactly at totalSimPackets.
            burstEndPacketSeq = min(
                packetSeq + dataPacketsPerWor,
                totalSimPackets,
            )
            burstPacketSeqs = list(
                range(packetSeq + 1, burstEndPacketSeq + 1)
            )
            packetSeq = burstEndPacketSeq
            worPacketSeq = burstPacketSeqs[0]
            burstTransactionId = f"{self.id}|{worPacketSeq}"
            for burstPacketSeq in burstPacketSeqs:
                packetTransactionOverrides[
                    f"{self.id}|{burstPacketSeq}"
                ] = burstTransactionId

            self.mode = "RX"
            self.batteryUpdate(env, self.currentRx)
            self.setIconColorByMode(env, get_linenumber())

            #carrier sensing
            if(carrier_sensing_ed ==1): 
                while(len(self.packetSourcesAtRx) != 0):
                    yield env.timeout(1)
                    # if(debug):
                    #     print("ED: waiting till medium is idle")

            # $$$$$$$$$$$$$$$$$
            # if(packetSeq == 95):
            #     global realtime_graphics
            #     global debug
            #     realtime_graphics = 1
            #     debug = 1
            
            if(repeater_sleep_algo):
                if(self.worAckReceived == -1):
                    # Send one WOR/ACK exchange for the complete DATA burst.
                    self.nextRp = -1 #broadcast WOR
                    seqNr = f"{self.id}|{worPacketSeq}|{round(env.now, 1)}|WOR_up"
                    addTime = round(env.now, 1)
                    self.tx_activity["active"] = True
                    self.createPackets(packetType="WOR_up", premlen=-1, seqNr=seqNr, addTime=addTime)
                    self.pendingWorAckTransaction = packetTransactionId(seqNr)
                    self.pendingWorAckCandidates = {
                        candidate.id
                        for candidate in nodes
                        if candidate.type.lower() == "rp"
                        and not self.packet[candidate.id].lost
                    }
                    self.tx_activity["start"] = env.now
                    self.tx_activity["end"] = env.now + self.packet[0].rectime
                    self.tx_activity["preamble_duration"] = self.packet[0].Tprem
                    self.tx_activity["tx_packet_type"] = "WOR_up"
                    self.worAckReceived = 0
                    self.tx_status_file.write(str(env.now))
                    yield env.process(self.transmit(env))

                    self.mode = "RX"
                    self.batteryUpdate(env, self.currentRx)
                    self.setIconColorByMode(env, get_linenumber())
                    k = 0
                    while (self.worAckReceived == 0):
                        yield env.timeout(1) #waiting for WOR ACK
                        k = k + 1
                        if(k > 20000):
                            self.worAckReceived = 1
                            print("ED:",self.id,"WOR ACK wait timeout")
                            break

                    if(self.worAckReceived == 1):
                        self.worAckReceived = -1
                        self.pendingWorAckTransaction = None
                        self.pendingWorAckCandidates.clear()
                        for currentPacketSeq in burstPacketSeqs:
                            if(carrier_sensing_ed ==1):
                                while(len(self.packetSourcesAtRx) != 0):
                                    yield env.timeout(1)

                            if OPPORTUNISTIC and router.gateways():
                                router.choose_path(self.id,router.gateways()[0],env.now)
                                op_stats['generated'] += 1
                            seqNr = f"{self.id}|{currentPacketSeq}|{round(env.now, 1)}|DATA_up"
                            addTime = round(env.now, 1)
                            self.tx_activity["active"] = True
                            self.createPackets(packetType="DATA_up", intendedRxId=self.nextRp, seqNr=seqNr, addTime=addTime)
                            self.tx_activity["start"] = env.now
                            self.tx_activity["end"] = env.now + self.packet[0].rectime
                            self.tx_activity["preamble_duration"] = self.packet[0].Tprem
                            self.tx_activity["tx_packet_type"] = "DATA_up"
                            self.sent = self.sent + 1
                            generatedDataPacketCount += 1
                            if generatedDataPacketCount == totalSimPackets:
                                lastPacketGenTime = env.now
                                if(debug):
                                    print(
                                        f"[GEN_DONE] T={env.now:.2f} ED={self.id} "
                                        f"generatedDataPacketCount={generatedDataPacketCount} "
                                        f"lastPacketGenTime={lastPacketGenTime:.2f}"
                                    )
                            self.tx_status_file.write(" "+str(env.now))
                            yield env.process(self.transmit(env))

            else:
                for currentPacketSeq in burstPacketSeqs:
                    if(carrier_sensing_ed ==1):
                        while(len(self.packetSourcesAtRx) != 0):
                            yield env.timeout(1)

                    if OPPORTUNISTIC and router.gateways():
                        router.choose_path(self.id,router.gateways()[0],env.now)
                        op_stats['generated'] += 1
                    seqNr = f"{self.id}|{currentPacketSeq}|{round(env.now, 1)}|DATA_up"
                    addTime = round(env.now, 1)
                    self.tx_activity["active"] = True
                    self.createPackets(packetType="DATA_up", seqNr=seqNr, addTime=addTime)
                    self.tx_activity["start"] = env.now
                    self.tx_activity["end"] = env.now + self.packet[0].rectime
                    self.tx_activity["preamble_duration"] = self.packet[0].Tprem
                    self.tx_activity["tx_packet_type"] = "DATA_up"
                    self.sent = self.sent + 1
                    generatedDataPacketCount += 1
                    if generatedDataPacketCount == totalSimPackets:
                        lastPacketGenTime = env.now
                    self.tx_status_file.write(str(env.now))
                    yield env.process(self.transmit(env))


    #only for the transmission by end-devices
    def transmit(self, env, seqNr=None):
        if not self.available: return
        global packetSeq
        global lastPacketGenTime
        global totalSimPackets
        global nodes
        global lostPackets
        global collidedPackets
        global fignum
        self.mode = "TX"
        self.batteryUpdate(env, self.currentTx)
        self.setIconColorByMode(env, get_linenumber())

        if(debug):
            # print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Transmitted Packet:{self.id}|{packetSeq}|{self.tx_activity['tx_packet_type']}")
            print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Transmitted Packet:{self.packet[0].seqNr}")

        data_diag_event = None
        if self.packet[0].packetType == "DATA_up":
            experiment_event("data_tx",node=self.id,packet_id=self.packet[0].seqNr,node_type=self.type)
            data_diag = dataPacketDiagnostics.setdefault(
                self.packet[0].seqNr,
                {
                    "source": self.id,
                    "intendedFirstHop": self.packet[0].intendedRxNodeId,
                    "gatewayReceived": False,
                    "gatewayId": None,
                    "transmissions": [],
                },
            )
            data_diag_event = {
                "sender": self.id,
                "senderType": self.type,
                "start": env.now,
                "receivers": [],
            }
            data_diag["transmissions"].append(data_diag_event)

        wor_diag_event = None
        wor_diag_receivers = {}
        if (
            self.type.lower() == "ed"
            and self.packet[0].packetType in ("WOR_up", "WOR_down")
        ):
            logical_packet_id = "|".join(self.packet[0].seqNr.split("|")[:2])
            wor_diag = worPacketDiagnostics.setdefault(
                logical_packet_id,
                {
                    "source": self.id,
                    "transmissions": [],
                },
            )
            wor_diag_event = {
                "sender": self.id,
                "start": env.now,
                "preambleEnd": env.now + self.packet[0].Tprem,
                "airtimeEnd": env.now + self.packet[0].rectime,
                "receivers": [],
            }
            wor_diag["transmissions"].append(wor_diag_event)

        for i in range(0, len(nodes)):
            self.packet[i].addTime = round(env.now, 1)
            if(seqNr != None):
                self.packet[i].seqNr = seqNr            
            # A dedicated receive antenna is isolated from this node's own
            # transmission, so do not model the outgoing signal as an RX source.
            if(i == self.id and self.antennaType.lower() == "dual"):
                continue
            if wor_diag_event is not None and nodes[i].type.lower() != "ed":
                receiver_diag = {
                    "receiver": i,
                    "receiverType": nodes[i].type,
                    "distance": self.dist[i],
                    "startMode": nodes[i].mode,
                    "cadProcessActive": nodes[i].cadProcessActive,
                    "lastCadScanTimeAtStart": nodes[i].lastCadScanTime,
                }
                wor_diag_event["receivers"].append(receiver_diag)
                wor_diag_receivers[i] = receiver_diag
            if(
                debug
                and self.packet[i].packetType in ("WOR_up", "WOR_down")
                and not self.packet[i].lost
            ):
                time_since_scan = (
                    env.now - nodes[i].lastCadScanTime
                    if nodes[i].lastCadScanTime != 0
                    else None
                )
                print(
                    f"[WOR_START] T={env.now:.2f} TX={self.id} RX={i} "
                    f"seqNr={self.packet[i].seqNr} "
                    f"mode={nodes[i].mode} cadProcessActive={nodes[i].cadProcessActive} "
                    f"lastCadScanTime={nodes[i].lastCadScanTime:.2f} "
                    f"timeSinceCadScan={time_since_scan}"
                )
            if(self.packet[i].lost == 0): #checking if the packet reachs at node[i]
                if (self in nodes[i].packetSourcesAtRx):
                    print("ERROR: packet",self.packet[i].seqNr, "from node",self.id,"is already in node",i,"RX")
                else:
                    nodes[i].packetSourcesAtRx.append(self)
                    # checking collision at the start of packet reception
                    if (checkcollision(self.packet[i], nodes[i])==1):
                        self.packet[i].collided = 1
                    else:
                        self.packet[i].collided = 0
        
        self.txPackets.append(self.packet[0].seqNr)

        if(realtime_graphics and graphics and fignum <= ROUTE_DIAGRAM_LIMIT):
            self.drawTxArrows()
            self.drawTime(env)
            self.drawTransmittingInfo()
            self.markCollidedArrows()
            self.drawCollisionInfo()
            if SHOW_ROUTING_OVERLAY and self.packet[0].packetType == 'DATA_up':
                draw_routing_overlay(self.packet[0].seqNr)
            else:
                clear_routing_overlay()
            if(slideShowPause):
                plt.pause(slideShowPause)
            else:
                plt.waitforbuttonpress()
            ext = ".png"
            figname = str(fignum) + ext
            save_path = os.path.join("route diagrams", figname)
            fignum +=1
            plt.savefig(save_path, dpi=100)
        
        # air time (take first packet rectime)
        yield env.timeout(self.packet[0].rectime)
        self.tx_activity["active"] = False
        self.tx_status_file.write(" "+str(env.now)+"\n")
        self.mode = "RX"
        self.batteryUpdate(env, self.currentRx)
        self.setIconColorByMode(env, get_linenumber())
        self.extendRxIdleDeadline(env)

        if(realtime_graphics and graphics and fignum <= ROUTE_DIAGRAM_LIMIT):
            self.eraseTxArrows()

        # if packet did not collide, add it in list of received packets
        # unless it is already in
        nodesThatReceivedPkt = []
        for i in range(0, len(nodes)):
            if(i != self.id):
                if i in wor_diag_receivers:
                    receiver_diag = wor_diag_receivers[i]
                    last_scan = nodes[i].lastCadScanTime
                    receiver_diag["endMode"] = nodes[i].mode
                    receiver_diag["lastCadScanTimeAtEnd"] = last_scan
                    receiver_diag["scanOccurredDuringPreamble"] = (
                        wor_diag_event["start"]
                        <= last_scan
                        < wor_diag_event["preambleEnd"]
                    )
                    if self.packet[i].lost:
                        outcome = "out_of_range"
                    elif self.packet[i].collided != 0:
                        outcome = "collision"
                    elif self.packet[i].processed != 1:
                        outcome = "not_processed"
                    elif nodes[i].canReceivePacket():
                        outcome = "scheduled_receive"
                    else:
                        outcome = "receiver_unavailable"
                    receiver_diag["outcome"] = outcome
                if data_diag_event is not None and nodes[i].type.lower() != "ed":
                    if self.packet[i].lost:
                        outcome = "out_of_range"
                    elif self.packet[i].collided != 0:
                        outcome = "collision"
                    elif self.packet[i].processed != 1:
                        outcome = "not_processed"
                    elif nodes[i].canReceivePacket():
                        outcome = "scheduled_receive"
                    else:
                        outcome = "receiver_unavailable"
                    data_diag_event["receivers"].append(
                        {
                            "receiver": i,
                            "receiverType": nodes[i].type,
                            "outcome": outcome,
                            "mode": nodes[i].mode,
                            "cadProcessActive": nodes[i].cadProcessActive,
                            "collided": self.packet[i].collided,
                            "processed": self.packet[i].processed,
                            "distance": self.dist[i],
                        }
                    )
                if self.packet[i].lost:
                    lostPackets.append(f"{nodes[i].type.upper()}:{nodes[i].id} SeqNr:{self.packet[i].seqNr}")
                else:
                    if ((self.packet[i].collided == 0) and (self.packet[i].processed == 1)):
                        if (nodes[i].canReceivePacket()):
                            if(debug):
                                print(f"called nodes[{i}].receive() from node {self.id}")
                            if OPPORTUNISTIC and self.packet[i].packetType == 'DATA_up':
                                nodes[i].op_observe(self.packet[i].seqNr, self.id)
                            env.process(nodes[i].receive(env, self.packet[i], self.packet[i].seqNr, self.distanceValue, self.nextRp, self.id))
                            nodesThatReceivedPkt.append(i)
                        else:
                            if(debug):
                                print(f"nodes[{i}] is in {nodes[i].mode} mode, cannot receive packet from node {self.id}")
                                if self.packet[i].packetType in ("WOR_up", "WOR_down"):
                                    print(
                                        f"[WOR_REJECT] T={env.now:.2f} TX={self.id} RX={i} "
                                        f"seqNr={self.packet[i].seqNr} "
                                        f"mode={nodes[i].mode} cadProcessActive={nodes[i].cadProcessActive} "
                                        f"lastCadScanTime={nodes[i].lastCadScanTime:.2f} "
                                        f"cadExitTime={nodes[i].cadExitTime} "
                                        f"cadExitReason={nodes[i].cadExitReason}"
                                    )
                    else:
                        # XXX only for debugging
                        collidedPackets.append(f"{nodes[i].type.upper()}:{nodes[i].id} SeqNr:{self.packet[i].seqNr}")
        
        # if(debug):
        #     print("|____Nodes that received the packet:",nodesThatReceivedPkt)

        # complete packet has been received by base station
        # can remove it
        for i in range(0, len(nodes)):
            if (self in nodes[i].packetSourcesAtRx):
                nodes[i].packetSourcesAtRx.remove(self)
            # reset the packet
            self.packet[i].collided = 0
            self.packet[i].processed = 0



    def receive(self, env, packet, seqNr, prevDistanceValue, nextRp, prevRp):
        """Track active receive handlers so an older flow cannot put an RP to sleep."""
        is_repeater = self.type.lower() == "rp"
        if is_repeater:
            self.activeReceiveProcesses += 1
            self.extendRxIdleDeadline(env)
        try:
            result = yield env.process(
                self._receive(
                    env,
                    packet,
                    seqNr,
                    prevDistanceValue,
                    nextRp,
                    prevRp,
                )
            )
            return result
        finally:
            if is_repeater:
                self.activeReceiveProcesses -= 1
                self.extendRxIdleDeadline(env)


    def _receive(self, env, packet, seqNr, prevDistanceValue, nextRp, prevRp):
        global nodes
        global lastTimePacketRecBS
        # yield env.timeout(repeaterProcessingTime) #wait for the processing time
        transactionId = packetTransactionId(seqNr)

        data_receive_event = None
        if packet.packetType == "DATA_up" and self.type.lower() == "rp":
            data_diag = dataPacketDiagnostics.setdefault(
                seqNr,
                {
                    "source": packet.nodeid,
                    "intendedFirstHop": -1,
                    "gatewayReceived": False,
                    "gatewayId": None,
                    "transmissions": [],
                },
            )
            data_receive_event = {
                "receiver": self.id,
                "time": env.now,
                "prevRp": prevRp,
                "packetNextRp": nextRp,
                "receiverNextRp": self.nextRp,
                "mode": self.mode,
                "worAckReceived": self.worAckStateByTransaction.get(
                    transactionId, -1
                ),
                "awaitingToSendWorAck": self.awaitingToSendWorAck,
                "standbyBufferCount": self.standbyBufferCount,
                "decision": "entered_receive",
            }
            data_diag.setdefault("receiveEvents", []).append(data_receive_event)

        if (self.distanceValue >= prevDistanceValue and (packet.packetType == "DATA_up" or packet.packetType == "WOR_up")):
            self.cadScanSyncProcess(env, packet, seqNr, prevRp)
            # A packet received directly from an ED is the packet that may
            # need standby recovery; it is not evidence that a downstream
            # infrastructure node has already forwarded it.
            if nodes[prevRp].type.lower() != "ed":
                self.lowerDistanceRecBuffer.append(
                    [seqNr, nodes[prevRp].batteryPercentage, prevRp]
                )
            if(
                self.type.lower() == "rp"
                and packet.packetType == "WOR_up"
                and nodes[prevRp].type.lower() != "ed"
                and self.nearestGwId == nodes[prevRp].nearestGwId
            ):
                # A WOR from any suitable upstream repeater confirms that the
                # forwarding direction is awake.  It therefore releases every
                # DATA transaction already waiting for upstream readiness; the
                # WOR sequence number does not have to match the held DATA.
                for pendingTransaction, ackState in list(
                    self.worAckStateByTransaction.items()
                ):
                    if ackState == 0:
                        self.worAckStateByTransaction[pendingTransaction] = 1

        if(self.type.lower() == "rp" and packet.packetType == "WOR_up" and nodes[packet.nodeid].type.lower() != "ed"):
            acknowledgedNode = packet.nodeAcknowledged
            if(
                0 <= acknowledgedNode < len(nodes)
                and nodes[acknowledgedNode].type.lower() == "ed"
                and self.pendingEdWorAcks.get(transactionId)
                == acknowledgedNode
            ):
                if(debug):
                    print("Rp:",self.id,"backing off without sending a WOR-ACK to ED:",acknowledgedNode)
                self.pendingEdWorAcks.pop(transactionId, None)
                self.syncPendingEdWorAckState()

        if seqNr not in self.recPackets:
            self.recPackets.append(seqNr)
        else:
            dataPacketCanStillBeHandled = (
                self.type.lower() == "rp"
                and packet.packetType in ("DATA_up", "DATA_down")
                and seqNr not in self.handledDataPackets
            )
            if not dataPacketCanStillBeHandled:
                if data_receive_event is not None:
                    data_receive_event["decision"] = "duplicate_already_handled"
                return 0
        
        if(debug):
            print(f"Node {self.id}({self.type.upper()}) Processing Packet:{seqNr}")

        if packet.packetType == 'DATA_up' and self.type.lower() == 'rp' and routing_mode() in ('flood','shortest_hop','weighted'):
            yield env.process(self.experimental_repeat(env,seqNr,prevRp))
            return 0

        if OPPORTUNISTIC and packet.packetType == 'DATA_up':
            if self.type.lower() == 'rp':
                self.op_observe(seqNr,prevRp)
                if data_receive_event is not None:
                    data_receive_event['decision'] = 'opportunistic_candidate'
                yield env.process(self.opportunistic_repeat(env,packet,seqNr,prevRp))
                return 0
            if self.type.lower() == 'gw':
                op_stats['gateway_receive_events'] += 1
                if seqNr not in packetsRecBS:
                    op_stats['delivered'] += 1
                    op_traces[seqNr].append(self.id)
                    visual_gateway_parents[seqNr][self.id] = prevRp
                    visual_delivered.add(seqNr)
                    visual_event(seqNr, 'gateway_delivered', gateway=self.id,
                                 previous_hop=prevRp)
                    if graphics and realtime_graphics and SHOW_ROUTING_OVERLAY:
                        draw_routing_overlay(seqNr)
                        os.makedirs('route diagrams/completed_routes', exist_ok=True)
                        safe_id = seqNr.replace('|', '_')
                        # Exact 3072 x 1505 pixels for completed routes.
                        # Restore the normal snapshot size afterwards (1536 x 752 at 100 dpi).
                        completed_fig = plt.gcf()
                        original_size = completed_fig.get_size_inches().copy()
                        try:
                            completed_fig.set_size_inches(15.36, 7.525, forward=False)
                            completed_fig.savefig(
                                f'route diagrams/completed_routes/{safe_id}.png',
                                dpi=200
                            )
                        finally:
                            completed_fig.set_size_inches(original_size, forward=False)

        #check if it is a gateway
        if (self.type.lower() == "gw"):

            if(repeater_sleep_algo):

                if(packet.packetType == "WOR_up" and (packet.intendedRxNodeId == self.id or packet.intendedRxNodeId == -1)):

                    premlen = self.tPreamToPremlen(self.cadPeriodity)
                    yield  env.timeout(self.timeTillNextWorTxBegin(env, premlen))
                    if(carrier_sensing_rp ==1):
                        while(len(self.packetSourcesAtRx) != 0):
                            yield env.timeout(self.cadPeriodity)

                    self.packetsFifo.put(packet)
                    with self.nTransmitters.request() as req:
                        yield req
                        outputPacket = yield self.packetsFifo.get()

                        if(carrier_sensing_rp ==1):
                            while(len(self.packetSourcesAtRx) != 0):
                                yield env.timeout(self.cadPeriodity)
                        
                        if(outputPacket.packetType == "WOR_up"):
                            self.tx_activity["active"] = True
                            self.createPackets("WOR_up", -1, nodeAcknowledged=outputPacket.nodeid, seqNr=outputPacket.seqNr)
                            self.tx_activity["start"] = env.now
                            self.tx_activity["end"] = env.now + self.packet[0].rectime
                            self.tx_activity["preamble_duration"] = self.packet[0].Tprem
                            self.tx_activity["tx_packet_type"] = "WOR_up"
                            self.tx_status_file.write(str(env.now))
                            yield env.process(self.transmit(env))

                elif(packet.packetType == "DATA_up"):
                    #Do no more transmissions. Account the packets received.
                    if(debug):
                        print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr}")
                        # print("T =",env.now, "|GW",self.id, "Received Packet:",seqNr,"\n")
                    if seqNr not in packetsRecBS:
                        packetsRecBS.append(seqNr)
                        experiment_event("gateway_delivery", node=self.id, packet_id=seqNr)
                        data_diag = dataPacketDiagnostics.setdefault(
                            seqNr,
                            {"source": packet.nodeid, "intendedFirstHop": -1, "transmissions": []},
                        )
                        data_diag["gatewayReceived"] = True
                        data_diag["gatewayId"] = self.id
                        x,y,t,pktType =seqNr.split("|")
                        latency = env.now -float(t)
                        # print("Latency:",latency)
                        packetLatencies.append(latency)  
                        lastTimePacketRecBS = env.now        
                        if(debug):
                            print(f"[GW_RX_TIME] T={env.now:.2f} GW={self.id} lastTimePacketRecBS={lastTimePacketRecBS:.2f}")
            
            else:
                #Do no more transmissions. Account the packets received.
                if(debug):
                    print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr}")
                    # print("T =",env.now, "|GW",self.id, "Received Packet:",seqNr,"\n")
                if seqNr not in packetsRecBS:
                    packetsRecBS.append(seqNr)
                    experiment_event("gateway_delivery", node=self.id, packet_id=seqNr)
                    data_diag = dataPacketDiagnostics.setdefault(
                        seqNr,
                        {"source": packet.nodeid, "intendedFirstHop": -1, "transmissions": []},
                    )
                    data_diag["gatewayReceived"] = True
                    data_diag["gatewayId"] = self.id
                    x,y,t,pktType =seqNr.split("|")
                    latency = env.now -float(t)
                    # print("Latency:",latency)
                    packetLatencies.append(latency)
                    lastTimePacketRecBS = env.now 
                    if(debug):
                        print(f"[GW_RX_TIME] T={env.now:.2f} GW={self.id} lastTimePacketRecBS={lastTimePacketRecBS:.2f}")
            
            #overall receiving rate calculation when 50% of the packets are received 
            global totalSimPackets
            global Q1_time
            global Q2_time
            global Q3_time
            global predicted_DER
            if(len(packetsRecBS) == int(totalSimPackets*predicted_DER*1/4)):
                Q1_time = env.now
            if(len(packetsRecBS) == int(totalSimPackets*predicted_DER*2/4)):
                Q2_time = env.now  
            if(len(packetsRecBS) == int(totalSimPackets*predicted_DER*3/4)):
                Q3_time = env.now
            


        #check if it is an end-device
        elif (self.type.lower() == "ed"):
            if(repeater_sleep_algo):
                matchingWorAck = (
                    packet.packetType == "WOR_up"
                    and self.worAckReceived == 0
                    and nodes[packet.nodeid].type.lower() != "ed"
                    and packet.nodeAcknowledged == self.id
                    and transactionId == self.pendingWorAckTransaction
                    and packet.nodeid in self.pendingWorAckCandidates
                )
                if matchingWorAck:
                    self.worAckReceived = 1
                    self.nextRp = packet.nodeid
                    if(debug):
                        print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received WOR ACK:{seqNr} | Next RP set to {self.nextRp}")
                elif(
                    packet.packetType == "WOR_up"
                    and self.worAckReceived == 0
                    and nodes[packet.nodeid].type.lower() != "ed"
                    and debug
                ):
                    print(
                        f"Node {self.id}(ED) ignored unrelated WOR ACK "
                        f"{seqNr} from Node {packet.nodeid}; "
                        f"acknowledged={packet.nodeAcknowledged}, "
                        f"pending={self.pendingWorAckTransaction}"
                    )
                elif(packet.packetType == "DATA_up" or packet.packetType == "DATA_down"):
                    if(debug):
                        print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr}")
            
            else:
                if(debug):
                    print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr}")
        
        #if it is a repeater
        else:
            if(repeater_sleep_algo):
                if(debug):
                    print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr} from Node {prevRp}({nodes[prevRp].type.upper()})")

                if(packet.packetType == "WOR_up" and nodes[prevRp].type.lower() == "ed"):
                    self.pendingEdWorAcks[transactionId] = prevRp
                    self.syncPendingEdWorAckState()
                    self.worAckStateByTransaction[transactionId] = 0
                    yield env.timeout(random.uniform(packet.rectime*0.0, packet.rectime*4.0))
                    # yield env.timeout(random.expovariate(1.0/float(packet.rectime*repeatDelayMultiplier)))
                    if(carrier_sensing_rp ==1):
                        while(len(self.packetSourcesAtRx) != 0):
                            yield env.timeout(random.uniform(1,10))

                    premlen = self.worPremlenCalc(env) # WOR preamble size in symbols with a random factor added
                    yield  env.timeout(self.timeTillNextWorTxBegin(env, premlen))
                    if(carrier_sensing_rp ==1):
                        while(len(self.packetSourcesAtRx) != 0):
                            yield env.timeout(self.cadPeriodity)

                    if self.pendingEdWorAcks.get(transactionId) == prevRp:
                        with self.nTransmitters.request() as req:
                            yield req
                            edId,packetSeq,genTime,pktType = seqNr.split("|")

                            if(carrier_sensing_rp ==1):
                                while(len(self.packetSourcesAtRx) != 0):
                                    yield env.timeout(self.cadPeriodity)

                            if self.pendingEdWorAcks.get(transactionId) != prevRp:
                                if(debug):
                                    print(
                                        f"Node {self.id} not sending WOR ACK to ED "
                                        f"{edId} for transaction {transactionId}"
                                    )
                                return 0
                            self.tx_activity["active"] = True
                            self.createPackets(
                                pktType,
                                premlen,
                                self.nextRp,
                                prevRp,
                                seqNr,
                                round(env.now, 1),
                            )
                            self.tx_activity["start"] = env.now
                            self.tx_activity["end"] = env.now + self.packet[0].rectime
                            self.tx_activity["preamble_duration"] = self.packet[0].Tprem
                            self.tx_activity["tx_packet_type"] = pktType
                            self.tx_status_file.write(str(env.now))
                            yield env.process(self.transmit(env))
                            self.pendingEdWorAcks.pop(transactionId, None)
                            self.syncPendingEdWorAckState()
                    
                else:
                    if(positional_algo):
                        standby = 0

                        if(nodes[prevRp].type.lower()!="ed" and self.nearestGwId!=nodes[prevRp].nearestGwId):
                            return 0

                        if(packet.packetType == "WOR_up" or packet.packetType == "DATA_up"):
                            if(
                                self.distanceValue < prevDistanceValue
                                or prevDistanceValue == -1
                            ):
                                
                                packetInfo = [seqNr, prevRp]
                                
                                if(packet.packetType == "WOR_up" and self.nearestGwId==nodes[prevRp].nearestGwId):
                                    self.worAckStateByTransaction.setdefault(
                                        transactionId, 0
                                    )

                                if(standby_repeater_algo):
                                    standbyCandidate = (
                                        self.id != nextRp
                                        and nextRp != -1
                                        and nodes[nextRp].type.lower() == "rp"
                                        and self.distanceValue
                                        > nodes[nextRp].distanceValue
                                    )
                                    if standbyCandidate:
                                        
                                        if(
                                            packet.packetType == "DATA_up"
                                            and self.worAckStateByTransaction.get(
                                                transactionId, -1
                                            ) == 0
                                        ):
                                            k = 0
                                            while(True):
                                                yield env.timeout(10)
                                                k +=1
                                                if(
                                                    self.worAckStateByTransaction.get(
                                                        transactionId, -1
                                                    ) == 1
                                                    or k == 1000
                                                ):
                                                    if(debug and k==1000):
                                                        print(f"Node {self.id}({self.type.upper()}) didn't receive a WOR-ACK for Pkt:{seqNr}")
                                                    break
                                        elif(
                                            packet.packetType == "DATA_up"
                                            and self.worAckStateByTransaction.get(
                                                transactionId, -1
                                            ) == -1
                                        ):
                                            if(debug):
                                                print(
                                                    f"Node {self.id}({self.type.upper()}) "
                                                    f"entering standby for DATA without "
                                                    f"matching WOR state: {seqNr}"
                                                )
                                        
                                        if(packet.packetType=="DATA_up"):
                                            standByTime = float(packet.rectime*repeatDelayMultiplier +5000)
                                        elif(packet.packetType=="WOR_up"):
                                            standByTime = float(packet.rectime*repeatDelayMultiplier)

                                        standby = 1
                                        self.standbyBufferCount += 1
                                        # standByTime = float(packet.rectime +packet.rectime*repeatDelayMultiplier*5+5000) 
                                        standby = yield env.process(self.standbyMode(env, packetInfo, standByTime, prevRp))
                                        self.standbyBufferCount -= 1
                                        if(standby == 1):
                                            if data_receive_event is not None:
                                                data_receive_event["decision"] = "standby_recovery_repeat"
                                            if(debug):
                                                print(f"Standby Recovery by Node {self.id} at T={round(env.now,2)} (Standby Time={round(standByTime,2)})")
                                            self.packetsFifo.put(packetInfo)
                                            with self.nTransmitters.request() as req:
                                                yield req
                                                packetInfoOut = yield self.packetsFifo.get()
                                                if(packet.packetType == "WOR_up" or packet.packetType == "WOR_down"):
                                                    yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1], packetInfoOut[1]))
                                                else:
                                                    yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
                                        else:
                                            if data_receive_event is not None:
                                                data_receive_event["decision"] = "standby_retain"
                                            if(debug):
                                                print(f"-*-*-*-Node {self.id} standby period ends with Sb={standby} Pkt-type={packet.packetType} (seqNr:{seqNr})")

                                    elif(self.id != nextRp and nextRp != -1 and nodes[nextRp].type.lower()=="gw" and packet.packetType=="DATA_up" and (len(self.packetsFifo.items) == 0) and self.awaitingToSendWorAck==0 and self.standbyBufferCount==0):
                                        if data_receive_event is not None:
                                            data_receive_event["decision"] = "not_selected_next_hop_is_gateway"

                                    elif(self.id != nextRp and nextRp != -1 and nodes[nextRp].type.lower()=="rp" and nodes[prevRp].distanceValue>nodes[nextRp].distanceValue>self.distanceValue):
                                        if(energy_aware_algo):
                                            if(round(nodes[nextRp].batteryPercentage%10) == 0):
                                                if(nodes[nextRp].batteryPercentage<(self.batteryPercentage)):
                                                    nodes[prevRp].nextRp = self.id
                                                    if(debug):
                                                        print("Energy Aware Algo changed node ",prevRp,"'s nextRp to ", self.id)
                                    
                                    elif(self.id == nextRp or nextRp == -1):
                                        # print("received by the one addressed!")
                                        if(
                                            packet.packetType == "DATA_up"
                                            and self.worAckStateByTransaction.get(
                                                transactionId, -1
                                            ) == 0
                                        ):
                                            k = 0
                                            while(True):
                                                yield env.timeout(10)
                                                k +=1
                                                if(
                                                    self.worAckStateByTransaction.get(
                                                        transactionId, -1
                                                    ) == 1
                                                    or k == 1000
                                                ):
                                                    break

                                        elif(
                                            packet.packetType == "DATA_up"
                                            and self.worAckStateByTransaction.get(
                                                transactionId, -1
                                            ) == -1
                                        ):
                                            if nextRp == -1:
                                                if data_receive_event is not None:
                                                    data_receive_event["decision"] = "drop_broadcast_not_expecting_data"
                                                return 0
                                            if debug:
                                                print(
                                                    f"Node {self.id}({self.type.upper()}) "
                                                    f"recovering addressed DATA without "
                                                    f"matching WOR state: {seqNr}"
                                                )
                                        
                                        # elif(packet.packetType=="WOR_up" and self.worAckReceived==1):
                                        #     return 0

                                        self.packetsFifo.put(packetInfo)
                                        if data_receive_event is not None:
                                            if (
                                                self.worAckStateByTransaction.get(
                                                    transactionId, -1
                                                ) == -1
                                            ):
                                                data_receive_event["decision"] = "addressed_recovery_repeat"
                                            else:
                                                data_receive_event["decision"] = "addressed_repeat"
                                        with self.nTransmitters.request() as req:
                                            yield req
                                            packetInfoOut = yield self.packetsFifo.get()
                                            if(packet.packetType == "WOR_up" or packet.packetType == "WOR_down"):
                                                yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1], packetInfoOut[1]))
                                            else:
                                                yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
                                else:
                                    self.packetsFifo.put(packetInfo)
                                    if data_receive_event is not None:
                                        data_receive_event["decision"] = "repeat_without_standby"
                                    with self.nTransmitters.request() as req:
                                        yield req
                                        packetInfoOut = yield self.packetsFifo.get()
                                        yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
                            
                            elif(self.distanceValue > prevDistanceValue and nodes[prevRp].type.lower()!="ed" and packet.packetType=="WOR_up" and len(self.packetsFifo.items)==0):
                                return 0

                    else:
                        packetInfo = [seqNr, prevRp]
                        self.packetsFifo.put(packetInfo)
                        with self.nTransmitters.request() as req:
                            yield req
                            packetInfoOut = yield self.packetsFifo.get()
                            yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
                    
            else:
                if(debug):
                    print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Received Packet:{seqNr}")

                if(positional_algo):
                    standby = 0
                    
                    if(self.distanceValue < prevDistanceValue or prevDistanceValue == -1):
                        
                        packetInfo = [seqNr, prevRp]
                        
                        if(standby_repeater_algo):           
                            if(self.id != nextRp and nextRp != -1 and nodes[nextRp].type.lower()=="rp" and self.distanceValue>nodes[nextRp].distanceValue and self.distanceValue<nodes[prevRp].distanceValue):
                                standby = 1
                                standByTime = float(self.packet[0].rectime +self.packet[0].rectime*repeatDelayMultiplier*5)
                                standby = yield env.process(self.standbyMode(env, packetInfo, standByTime, prevRp))
                                if(standby == 1):
                                    self.packetsFifo.put(packetInfo)
                                    with self.nTransmitters.request() as req:
                                        yield req
                                        packetInfoOut = yield self.packetsFifo.get()
                                        yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))

                            elif(self.id != nextRp and nextRp != -1 and nodes[nextRp].type.lower()=="rp" and nodes[prevRp].distanceValue>nodes[nextRp].distanceValue>self.distanceValue):
                                if(energy_aware_algo):
                                    if(round(nodes[nextRp].batteryPercentage%10) == 0):
                                        if(nodes[nextRp].batteryPercentage<(self.batteryPercentage)):
                                            nodes[prevRp].nextRp = self.id
                            
                            elif(self.id == nextRp or nextRp == -1):
                                # print("received by the one addressed!")              
                                self.packetsFifo.put(packetInfo)
                                with self.nTransmitters.request() as req:
                                    yield req
                                    packetInfoOut = yield self.packetsFifo.get()
                                    yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
                        else:
                            self.packetsFifo.put(packetInfo)
                            with self.nTransmitters.request() as req:
                                yield req
                                packetInfoOut = yield self.packetsFifo.get()
                                yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))
            
                else:
                    packetInfo = [seqNr, prevRp]
                    self.packetsFifo.put(packetInfo)
                    with self.nTransmitters.request() as req:
                        yield req
                        packetInfoOut = yield self.packetsFifo.get()
                        yield env.process(self.repeat(env, packetInfoOut[0], packetInfoOut[1]))


    # THESIS: Local sensing; aggregated values are NOT sent over LoRa yet.
    def collect_sensor(self, value):
        if self.type.lower() == 'rp':
            self.sensorSamples.append(float(value))

    def aggregate_sensor(self):
        if not self.sensorSamples:
            return None
        sample = {'node': self.id, 'count': len(self.sensorSamples),
                  'mean': sum(self.sensorSamples)/len(self.sensorSamples)}
        self.sensorSamples.clear()
        return sample

    def op_observe(self, seqNr, transmitter):
        # A successfully decoded DATA_up packet can suppress a queued backup.
        pending = self.opPending.get(seqNr)
        if pending is None or not OPPORTUNISTIC or not OP_SUPPRESSION_ENABLED:
            return
        gw = pending['gateway']
        downstream = router.downstream(gw)
        if downstream.get(transmitter,math.inf) < downstream.get(self.id,math.inf):
            if not pending['cancelled']:
                pending['cancelled'] = True
                op_stats['suppressed'] += 1
                experiment_event("suppressed", node=self.id, packet_id=seqNr)
                visual_suppressed[seqNr].add(self.id)
                info = visual_candidates.get(seqNr, {}).get(self.id)
                if info is not None:
                    info['status'] = 'suppressed'
                visual_event(seqNr, 'suppressed', node=self.id,
                             overheard_transmitter=transmitter)

    def experimental_repeat(self, env, seqNr, prevRp):
        """Forward DATA through existing radio processes; one forwarding per packet/repeater."""
        if not self.available or seqNr in self.opForwarded: return
        origin=int(seqNr.split('|',1)[0])
        gws=router.gateways()
        if not gws: return
        gw=gws[0]
        mode=routing_mode()
        if mode == 'flood':
            # Deduplicated broadcast. Each repeater broadcasts at most once.
            self.nextRp=-1
            delay=random.uniform(0,100)
        else:
            path=(router.shortest_hop_path(origin,gw) if mode=='shortest_hop'
                  else router.choose_path(origin,gw,env.now))
            if self.id not in path: return
            index=path.index(self.id)
            if index == 0 or index+1>=len(path) or path[index-1]!=prevRp: return
            self.nextRp=path[index+1]
            delay=0
        self.opForwarded.add(seqNr)
        experiment_event('forward_attempt',node=self.id,packet_id=seqNr,previous_hop=prevRp,algorithm=mode)
        yield env.timeout(delay)
        if not self.available: return
        with self.nTransmitters.request() as req:
            yield req
            if not self.available: return
            yield env.process(self.repeat(env,seqNr,prevRp,skip_op_delay=True))

    def opportunistic_repeat(self, env, packet, seqNr, prevRp):
        if seqNr in self.opForwarded or seqNr in self.opPending:
            return
        origin = int(seqNr.split('|',1)[0])
        gw_ids = router.gateways()
        if not gw_ids:
            op_stats['no_gateway'] += 1
            return
        gw = min(gw_ids,key=lambda gid:router.downstream(gid).get(prevRp,math.inf))
        choices = router.candidates(prevRp,origin,gw)
        experiment_event("candidate_list", node=self.id, packet_id=seqNr, candidate_count=len(choices))
        if self.id not in choices:
            op_stats['not_candidate'] += 1
            return
        if seqNr in self.handledDataPackets:
            return
        rank = choices.index(self.id)
        visual_candidates[seqNr][self.id] = {
            'rank': rank, 'status': 'pending',
            'previous_hop': prevRp, 'time_ms': env.now}
        visual_event(seqNr, 'candidate_pending', node=self.id,
                     previous_hop=prevRp, rank=rank)
        # One slot must exceed the DATA airtime so a lower-ranked relay can
        # overhear the complete earlier transmission before its timer fires.
        Tpream, Tpayload = airtime(sf,2,20,bw)
        data_airtime_ms = Tpream + Tpayload
        slot = max(packet.rectime, data_airtime_ms) + OP_GUARD_MS
        state = {'cancelled':False,'gateway':gw,'rank':rank}
        self.opPending[seqNr] = state
        self.extendRxIdleDeadline(env)
        op_stats['eligible_receptions'] += 1
        try:
            yield env.timeout(rank*slot + random.uniform(0,OP_JITTER_MS))
            if state['cancelled'] or seqNr in self.opForwarded:
                return
            if self.id not in router.candidates(prevRp,origin,gw):
                op_stats['candidate_changed'] += 1
                return
            # Forward only through the existing radio/WOR-aware simulator.
            # Select this relay's preferred next hop for the DATA_up packet.
            next_choices = router.candidates(self.id,origin,gw)
            if not next_choices:
                op_stats['dead_end'] += 1
                return
            self.nextRp = next_choices[0]
            with self.nTransmitters.request() as req:
                yield req
                if state['cancelled'] or seqNr in self.opForwarded:
                    return
                if len(op_traces[seqNr]) >= OP_TTL:
                    op_stats['ttl_drops'] += 1
                    return
                self.opForwarded.add(seqNr)
                op_stats['relay_attempts'] += 1
                op_traces[seqNr].append(self.id)
                visual_forward_parents[seqNr][self.id] = prevRp
                visual_candidates[seqNr][self.id]['status'] = 'forwarded'
                visual_event(seqNr, 'forward_attempt', node=self.id,
                             previous_hop=prevRp, rank=rank)
                yield env.process(self.repeat(env,seqNr,prevRp,skip_op_delay=True))
        finally:
            self.opPending.pop(seqNr,None)
            info = visual_candidates.get(seqNr, {}).get(self.id)
            if info is not None and info['status'] == 'pending':
                info['status'] = 'withdrawn'
                visual_event(seqNr, 'candidate_withdrawn', node=self.id)

    def standbyMode(self, env, packetInfo, standByTime, prevRp):
        global total_stanby
        global standby_retains
        global standby_recoveries
        global repeater_role_changes
        total_stanby += 1

        seqNr = packetInfo[0]
        x,y,t,pktType =seqNr.split("|")
        if pktType in ("DATA_up", "DATA_down"):
            self.handledDataPackets.add(seqNr)

        yield env.timeout(random.uniform(0.8*standByTime, 1.2*standByTime))

        # exactStandByTime = int(random.uniform(0.8*standByTime, 1.2*standByTime))
        # if(debug):
        #     print(f"Node {self.id}({self.type.upper()}) entering Standby for {exactStandByTime} ms at T={round(env.now,2)} (Pkt:{seqNr})")
        # k = 0
        # while(k < exactStandByTime/10):
        #     k +=1
        #     yield env.timeout(10)
        
        for item in self.lowerDistanceRecBuffer:
            if (item[0] == seqNr):
                if(energy_aware_algo):
                    if(round(item[1])%10 == 0):
                        if(item[1]<(self.batteryPercentage-10) and item[1] < (nodes[self.nextRpOriginal].batteryPercentage-10)):

                            if(nodes[prevRp].nextRpOriginal == -1):
                                nodes[prevRp].nextRpOriginal = nodes[prevRp].nextRp
                            nodes[prevRp].nextRp = self.id
                            if(self.nextRpOriginal != -1):
                                self.nextRp = self.nextRpOriginal
                            repeater_role_changes += 1

                standby_retains += 1
                return 0
    
        standby_recoveries += 1
        return 1
        

    def enableCad(self, env):
        global repeater_sleep_algo
        global state_data_logging
        global lastTimePacketRecBS
        global avgSendTime

        if(repeater_sleep_algo==0):
            return 0

        self.cadProcessActive = True
        self.cadExitTime = None
        self.cadExitReason = None
        if(debug):
            print(
                f"[CAD_PROCESS_START] T={env.now:.2f} Node={self.id} "
                f"type={self.type} avgSendTime={avgSendTime}"
            )
        
        if(self.type.lower() == "gw"):
            self.mode = "RX"
            self.batteryUpdate(env, self.currentRx)
        else:
            self.mode = "CAD"
            self.batteryUpdate(env, self.currentCad)
        self.setIconColorByMode(env, get_linenumber())

        yield env.timeout(random.uniform(0, self.cadPeriodity)) #initial random delay to make nodes unsynchronized

        while(True):

            if(self.mode == "CAD"):
                # CAD Scan: Checking WOR channel activity
                self.lastCadScanTime = env.now

                for node in self.packetSourcesAtRx:
                    is_wor = node.tx_activity["tx_packet_type"] in ("WOR_up", "WOR_down")
                    in_preamble = node.tx_activity["in_preamble"](env)
                    if(debug and is_wor):
                        print(
                            f"[CAD_SCAN_WOR] T={env.now:.2f} RX={self.id} TX={node.id} "
                            f"inPreamble={in_preamble} mode={self.mode}"
                        )
                    if in_preamble and is_wor:
                        self.mode = "RX"
                        self.batteryUpdate(env, self.currentRx)
                        self.setIconColorByMode(env, get_linenumber())
                        self.extendRxIdleDeadline(env)
                        if(debug):
                            print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Detected WOR Packet from Node {node.id} during CAD")

            # Return to CAD only after the complete protocol-aware idle hold
            # and only when no receive, standby, queue, TX, or ACK work remains.
            if(
                self.type.lower() == "rp"
                and self.mode == "RX"
                and env.now >= self.rxIdleDeadline
                and not self.repeaterHasPendingWork()
            ):
                self.mode = "CAD"
                self.batteryUpdate(env, self.currentCad)
                self.setIconColorByMode(env, get_linenumber())
                self.worAckReceived = -1
                if(debug):
                    print(
                        f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) "
                        f"Switching back to CAD after idle deadline "
                        f"{self.rxIdleDeadline:.2f}"
                    )

            if(self.type.lower()!="gw"):
                if(state_data_logging):    
                    if(self.cadTimingAdjustment != 0):
                        yield env.timeout(self.cadPeriodity*(1+self.clockAccuracy)-2 +self.cadTimingAdjustment)
                        self.cadTimingAdjustment = 0
                    else:
                        yield env.timeout(self.cadPeriodity*(1+self.clockAccuracy)-2)
                    if(self.mode == "CAD"):
                        self.state_diagram_file.write(f"{env.now} CAD_Scan_rise\n")
                        yield env.timeout(1)
                        self.state_diagram_file.write(f"{env.now} CAD_Scan_fall\n")
                        yield env.timeout(1)
                    else:
                        yield env.timeout(2)
                else:
                    if(self.cadTimingAdjustment != 0):
                        yield env.timeout(self.cadPeriodity*(1+self.clockAccuracy) +self.cadTimingAdjustment)
                        self.cadTimingAdjustment = 0
                    else:
                        yield env.timeout(self.cadPeriodity*(1+self.clockAccuracy))
            else: #GW
                self.lastCadScanTime = env.now #hypothetically for a reference
                yield env.timeout(self.cadPeriodity*(1+self.clockAccuracy))
          
            #Exit CAD function after the end of the simulation
            generation_timeout = (
                lastPacketGenTime != 0
                and env.now > (lastPacketGenTime + 3600000)
            )
            if generation_timeout:
                exit_reason = "generation_timeout"
                self.cadProcessActive = False
                self.cadExitTime = env.now
                self.cadExitReason = exit_reason
                if(debug):
                    print(
                        f"[CAD_PROCESS_EXIT] T={env.now:.2f} Node={self.id} reason={exit_reason} "
                        f"lastPacketGenTime={lastPacketGenTime:.2f} "
                        f"lastTimePacketRecBS={lastTimePacketRecBS:.2f} "
                        f"gatewaySilence={env.now-lastTimePacketRecBS:.2f} "
                        f"(informationalOnly) mode={self.mode}"
                    )
                break

    
    def timeTillNextWorTxBegin(self, env, premlen=-1):
        global worPreambleDuration
        global bw
        sf = 7
        Tpream = 0
        Tsym = (2.0**sf)/bw
        if(premlen == -1):
            Tpream = worPreambleDuration
        else: 
            Tpream = (premlen + 4.25)*Tsym

        if(self.type.lower()!="gw"):
            if(Tpream>self.cadPeriodity):
                self.wor_data_file.write(f"{self.cadPeriodity}\n")
            else:
                self.wor_data_file.write(f"{Tpream}\n")
        
        timeTillNextCadRef = (self.cadPeriodity - (env.now - self.lastCadScanTime)%self.cadPeriodity)
        if (timeTillNextCadRef == self.cadPeriodity):
            timeTillNextCadRef = 0
        
        Twait = timeTillNextCadRef - Tpream/2
        if(Twait < 0):
            Twait = Twait + self.cadPeriodity
        return Twait
    

    def tPreamToPremlen(self, Tpream):
        global bw
        sf = 7
        Tsym = (2.0**sf)/bw
        premlen = int(Tpream/Tsym - 4.25) +random.choice([0,1,2,3,4,5,6,7,8,9,10])
        return premlen
    

    def premlenToTPream(self, premlen):
        global bw
        sf = 7
        Tsym = (2.0**sf)/bw
        Tpream = (premlen + 4.25)*Tsym
        return Tpream
    

    def worPremlenCalc(self, env):
        global nodeClockAccuracy
        global wor_preamble_shrinking_algo
        global worPreambleDuration
        global bw

        if(wor_preamble_shrinking_algo==0):
            return self.tPreamToPremlen(worPreambleDuration)
        
        if(self.worUpPacketHistory[0] == 0):
            return self.tPreamToPremlen(worPreambleDuration)
        
        sf = 7
        Tsym = (2.0**sf)/bw
        delta = 2*nodeClockAccuracy/1000000
        # Tpream = 2*delta*(env.now - self.worUpPacketHistory[0])+ (1+6+8)*Tsym
        Tpream = 2*delta*(env.now - self.worUpPacketHistory[0])+ (50)*Tsym
        if(debug):
            print(f"Node {self.id}({self.type.upper()}) Tpream:{round(Tpream,2)} history:{self.worUpPacketHistory}")
        if(Tpream >= worPreambleDuration):
            return self.tPreamToPremlen(worPreambleDuration)
        else:
            return self.tPreamToPremlen(Tpream)
        

    def cadScanSyncProcess(self, env, packet, seqNr, prevRp):
        global repeater_synchronization_algo
        global nodes
        if(repeater_synchronization_algo==False):
            return 0
        
        if(nodes[prevRp].nearestGwId != self.nearestGwId):
            return 0
        
        for item in self.lowerDistanceRecBuffer: #previously processed
            if (item[0] == seqNr):
                return 0

        if(nodes[prevRp].type.lower()!="ed" and (nodes[prevRp].distanceValue < self.distanceValue) and (packet.packetType=="WOR_up" or packet.packetType=="WOR_down") and self.nearestGwId==nodes[prevRp].nearestGwId):
            
            #keeping record of WOR packets from nodes closer to the gateway for calculating drift error
            if(packet.packetType=="WOR_up"):
                self.worUpPacketHistory.append(env.now)
            elif(packet.packetType=="WOR_down"):
                self.worUpPacketHistory.clear()
                self.worUpPacketHistory.extend([env.now]*self.worUpPacketHistory.maxlen)

            #calculating the CAD timing adjustment
            Tlast = self.lastCadScanTime + self.cadPeriodity*((env.now-self.lastCadScanTime)//self.cadPeriodity)
            Tf = packet.addTime + packet.Tprem
            Tref = Tf - packet.Tprem/2  #Equation 8 from paper
            self.cadTimingAdjustment = Tref - Tlast
            if(self.cadTimingAdjustment > self.cadPeriodity):
                self.cadTimingAdjustment = self.cadTimingAdjustment - self.cadPeriodity
            elif(self.cadTimingAdjustment < (-self.cadPeriodity)):
                self.cadTimingAdjustment = self.cadTimingAdjustment + self.cadPeriodity

            if(debug):
                print(f"Node {self.id}({self.type.upper()}) adjusted CAD scan timing by {round(self.cadTimingAdjustment,2)} ms in reference to packet from Node {nodes[prevRp].id}({nodes[prevRp].type.upper()})")


    def repeat(self, env, seqNr, prevRp, nodeAcknowledged=-1, skip_op_delay=False):
        if not self.available: return
        global nodes
        global packetsRecBS
        global collidedPackets
        global lostPackets
        global repeaterProcessingTime
        global fignum

        x,y,t,pktType =seqNr.split("|")
        if pktType in ("DATA_up", "DATA_down"):
            self.handledDataPackets.add(seqNr)

        self.mode = "RX"
        self.batteryUpdate(env, self.currentRx)
        self.setIconColorByMode(env, get_linenumber())

        # yield env.timeout(random.expovariate(1.0/float(nodes[prevRp].packet[0].rectime*repeatDelayMultiplier))) #wait random time with mean =airtime*repeatDelayMultiplier
        if not skip_op_delay:
            yield env.timeout(random.expovariate(1.0/10)) # native backoff

        if(pktType == "WOR_up" or pktType == "WOR_down"):
            premlen = self.worPremlenCalc(env) # WOR preamble size in symbols with a random factor added
            yield  env.timeout(self.timeTillNextWorTxBegin(env, premlen))
            if(carrier_sensing_rp ==1):
                while(len(self.packetSourcesAtRx) != 0):
                    yield env.timeout(self.cadPeriodity)
        else:
            if not skip_op_delay:
                yield env.timeout(random.expovariate(1.0/10)) # native backoff
            if(carrier_sensing_rp ==1):
                while(len(self.packetSourcesAtRx) != 0):
                    yield env.timeout(random.expovariate(1.0/float(self.packet[0].rectime*repeatDelayMultiplier)))

        if(repeater_sleep_algo):
            if(pktType == "WOR_up" or pktType == "WOR_down"):
                self.createPackets(pktType, premlen, intendedRxId=self.nextRp, nodeAcknowledged=nodeAcknowledged, seqNr=seqNr)
                self.tx_activity["tx_packet_type"] = pktType
            
            elif(pktType == "DATA_up" or pktType == "DATA_down"):
                self.createPackets(pktType, intendedRxId=self.nextRp, seqNr=seqNr)
                self.tx_activity["tx_packet_type"] = pktType

        else:
            self.createPackets("DATA_up", intendedRxId=self.nextRp, seqNr=seqNr)
            self.tx_activity["tx_packet_type"] = "DATA_up"

        if not self.available: return
        if pktType == "DATA_up": experiment_event("data_tx", node=self.id, packet_id=seqNr, node_type=self.type)
        self.tx_activity["active"] = True #starting transmission
        self.tx_activity["start"] = env.now
        self.tx_activity["end"] = env.now + self.packet[0].rectime
        self.tx_activity["preamble_duration"] = self.packet[0].Tprem
        self.tx_status_file.write(str(env.now))
        self.mode = "TX"
        self.batteryUpdate(env, self.currentTx)
        self.setIconColorByMode(env, get_linenumber())

        if(debug):
            print(f"\nT = {env.now:.2f}| Node {self.id}({self.type.upper()}) Forwarded Packet:{seqNr}")

        data_diag_event = None
        if pktType == "DATA_up":
            data_diag = dataPacketDiagnostics.setdefault(
                seqNr,
                {
                    "source": int(x),
                    "intendedFirstHop": -1,
                    "gatewayReceived": False,
                    "gatewayId": None,
                    "transmissions": [],
                },
            )
            data_diag_event = {
                "sender": self.id,
                "senderType": self.type,
                "start": env.now,
                "receivers": [],
            }
            data_diag["transmissions"].append(data_diag_event)
        
        self.txPackets.append(seqNr)
        global lastPacketGenTime
        if(lastPacketGenTime != 0 and self.txTimePercentage == 0 and lastPacketGenTime < env.now):
            self.txTimePercentage = (len(self.txPackets)*self.packet[0].rectime)/lastPacketGenTime
        
        for i in range(0, len(nodes)): #add the transmission at each applicable receiver
            self.packet[i].addTime = round(env.now, 1)
            self.packet[i].seqNr = seqNr
            self.packet[i].txBattery = self.batteryPercentage

            # A dedicated receive antenna is isolated from this node's own
            # transmission, so do not model the outgoing signal as an RX source.
            if(i == self.id and self.antennaType.lower() == "dual"):
                continue
            if(self.packet[i].lost == 0): #checking if the packet reachs at node[i]
                if (self in nodes[i].packetSourcesAtRx):
                    print("ERROR: Packet",self.packet[i].seqNr, "from node",self.id,"is already in node",i,"RX")
                else:
                    nodes[i].packetSourcesAtRx.append(self) 
                    # checking collision at the start of packet reception
                    if (checkcollision(self.packet[i], nodes[i])==1):
                        self.packet[i].collided = 1
                    else:
                        self.packet[i].collided = 0

        if(realtime_graphics and graphics and fignum <= ROUTE_DIAGRAM_LIMIT):
            self.drawTxArrows()
            self.drawTime(env)
            self.drawTransmittingInfo()
            self.markCollidedArrows()
            self.drawCollisionInfo()
            if SHOW_ROUTING_OVERLAY and self.packet[0].packetType == 'DATA_up':
                draw_routing_overlay(self.packet[0].seqNr)
            else:
                clear_routing_overlay()
            if(slideShowPause):
                plt.pause(slideShowPause)
            else:
                plt.waitforbuttonpress()
            ext = ".png"
            ext = ".png"
            figname = str(fignum) + ext
            save_path = os.path.join("route diagrams", figname)
            fignum +=1
            plt.savefig(save_path, dpi=100)
        
        # air time (take first packet rectime)
        yield env.timeout(self.packet[0].rectime)
        self.tx_activity["active"] = False
        self.tx_status_file.write(" "+str(env.now)+"\n")
        
        # Do not let completion of an older forwarding flow reset state needed
        # by a newer overlapping flow. The CAD process performs the eventual
        # transition after the idle deadline and pending-work checks.
        self.mode = "RX"
        self.batteryUpdate(env, self.currentRx)
        self.setIconColorByMode(env, get_linenumber())
        self.extendRxIdleDeadline(env)

        if(realtime_graphics and graphics and fignum <= ROUTE_DIAGRAM_LIMIT):
            self.eraseTxArrows()

        # if packet did not collide, add it in list of received packets
        # unless it is already in
        nodesThatReceivedPkt = []
        for i in range(0, len(nodes)):
            if(i != self.id):
                if data_diag_event is not None and nodes[i].type.lower() != "ed":
                    if self.packet[i].lost:
                        outcome = "out_of_range"
                    elif self.packet[i].collided != 0:
                        outcome = "collision"
                    elif nodes[i].canReceivePacket():
                        outcome = "scheduled_receive"
                    else:
                        outcome = "receiver_unavailable"
                    data_diag_event["receivers"].append(
                        {
                            "receiver": i,
                            "receiverType": nodes[i].type,
                            "outcome": outcome,
                            "mode": nodes[i].mode,
                            "cadProcessActive": nodes[i].cadProcessActive,
                            "collided": self.packet[i].collided,
                            "processed": self.packet[i].processed,
                            "distance": self.dist[i],
                        }
                    )
                if (self.packet[i].lost):
                    lostPackets.append(f"{nodes[i].type.upper()}:{nodes[i].id} SeqNr:{self.packet[i].seqNr}")
                else:
                    if (self.packet[i].collided == 0):
                        if (nodes[i].canReceivePacket()):
                            if(debug):
                                print(f"called nodes[{i}].receive() from node {self.id}")
                            if OPPORTUNISTIC and self.packet[i].packetType == 'DATA_up':
                                nodes[i].op_observe(self.packet[i].seqNr, self.id)
                            env.process(nodes[i].receive(env, self.packet[i], self.packet[i].seqNr, self.distanceValue, self.nextRp, self.id))
                            nodesThatReceivedPkt.append(i)
                        # if (self.packet[i].seqNr not in nodes[i].recPackets):
                        #     nodes[i].recPackets.append(self.packet[i].seqNr)
                        #     env.process(nodes[i].receive(env, self.packet[i], self.packet[i].seqNr, self.distanceValue, self.nextRp, self.id))
                        # if (nodes[i].distanceValue >= self.distanceValue):
                        #     nodes[i].lowerDistanceRecBuffer.append([seqNr,self.batteryPercentage, self.id])
                    else:
                        # XXX only for debugging
                        collidedPackets.append(f"{nodes[i].type.upper()}:{nodes[i].id} SeqNr:{self.packet[i].seqNr}")
        
        # if(debug):
        #     print("|____Nodes that received the packet:",nodesThatReceivedPkt)

        # complete packet has been received by base station
        # can remove it
        for i in range(0, len(nodes)):
            if (self in nodes[i].packetSourcesAtRx):
                nodes[i].packetSourcesAtRx.remove(self)
            # reset the packet
            self.packet[i].collided  = 0
            self.packet[i].processed = 0


    
    def transmissionSuccessRate(self):
        global packetsRecBS
        for seqNr in packetsRecBS:
            x,y,t,pktType =seqNr.split("|")
            if(self.id == int(x)):
                self.sentSuccessful += 1
        if(self.sent == 0):
            return 0
        else:
            return (float(self.sentSuccessful)/self.sent)


#
# this creates a packet associated between a pair of nodes
#
class myPacket():
    def __init__(self, nodeid, payloadLen, distance, rxNodeId,
                 txPower=14, sf=12, cr=4, bw=125, freq=860000000, packetType="OTHER", premlen=8, intendedRxNodeId=-1, nodeAcknowledged=-1, seqNr=None, addTime=None):
        global experiment
        global gamma
        global d0
        global var
        global Lpld0
        global GL
        global minsensi
        global nodes
        self.seqNr = seqNr
        self.addTime = addTime
        self.rxNodeId = rxNodeId
        self.intendedRxNodeId = intendedRxNodeId
        self.nodeAcknowledged = nodeAcknowledged
        self.nodeid = nodeid
        self.nearestGwId = nodes[nodeid].nearestGwId
        self.payloadLen = payloadLen
        self.preambleLen = premlen
        self.packetType = packetType

        #LoRa Parameters
        self.ptx  = txPower
        self.sf   = sf 
        self.cr   = cr
        self.bw   = bw
        self.freq = freq

        #Transmission related parameters
        if(distance != 0):
            Lpl = Lpld0 + 10*gamma*math.log10(distance/d0)
        else:
            Lpl = 0
        self.rssi = self.ptx - GL - Lpl - extra_link_loss(nodeid,rxNodeId)
        self.symTime = (2.0**self.sf)/self.bw

        self.collided = 0
        self.processed = 0
        if(self.bw == 125):
            minsensi = sensi[self.sf-7][1]
        elif(self.bw == 250):
            minsensi = sensi[self.sf-7][2]
        elif(self.bw == 500):
            minsensi = sensi[self.sf-7][3]
        self.lost = self.rssi < minsensi

        self.Tprem, self.Tpayload = airtime(self.sf,self.cr,self.payloadLen,self.bw, self.preambleLen)
        self.rectime = self.Tprem + self.Tpayload


        global debug
        # if(debug):
        #     print ("\nCreated pkt from Node {} to Node {} |lost: {}".format(self.nodeid, self.rxNodeId, self.lost))
        #     print ("  Distance", distance)
        #     print ("  Ptx: ",self.ptx)
        #     print ("  Lpl: ",Lpl)
        #     print ("  Prx: ", self.rssi)
        #     print ("  MinSensi: ",minsensi)
        #     print ("  Pkt Length: ",self.payloadLen)
        #     print ("  Freq: ", self.freq)
        #     print ("  SF:",self.sf," BW:",self.bw," CR:",self.cr)       


#
# Network graph for position & routing calculations
#
class Graph():
    def __init__(self, vertices):
        self.V = vertices
        self.graph = [[0 for column in range(vertices)]
                      for row in range(vertices)]
        
    def printSolution(self, dist, src):
        print("\nNode \t Distance from GW (Node ", src, ")")
        for node in range(self.V):
            print(node, "\t\t", dist[node])

    def minDistance(self, dist, sptSet):
        min_val = float('inf')
        min_index = -1
        for v in range(self.V):
            if dist[v] < min_val and sptSet[v] == False:
                min_val = dist[v]
                min_index = v
        return min_index
        
    def dijkstra(self, src):
        dist = [float('inf')] * self.V
        dist[src] = 0
        sptSet = [False] * self.V
        
        # Track visited nodes to identify isolated ones
        visited = set()
        
        for cout in range(self.V):
            u = self.minDistance(dist, sptSet)
            if u == -1:  # No reachable nodes found
                break
            sptSet[u] = True
            visited.add(u)
            for v in range(self.V):
                if (self.graph[u][v] > 0 and 
                    sptSet[v] == False and 
                    dist[v] > dist[u] + self.graph[u][v]):
                    dist[v] = dist[u] + self.graph[u][v]
        
        # Print isolated nodes (nodes not visited during traversal)
        isolated_nodes = set(range(self.V)) - visited
        if isolated_nodes:
            print(f"\nIsolated nodes from source {src}:", list(isolated_nodes))
        
        self.printSolution(dist, src)
        return dist
