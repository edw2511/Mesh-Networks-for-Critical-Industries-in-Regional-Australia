Command lines for useful tests

High traffic load:
    python run_seeds.py --test traffic --routing opportunistic
    python run_seeds.py --test traffic --routing flood

High network density:
    python run_seeds.py --test density --routing opportunistic
    python run_seeds.py --test density --routing flood

Mobility on-foot worker (0.8 m/s):
    python run_seeds.py --test mobility --routing opportunistic --profile walking
    python run_seeds.py --test mobility --routing flood --profile walking

Mobility, vehicle (8 m/s):
    python run_seeds.py --test mobility --routing opportunistic --profile vehicle
    python run_seeds.py --test mobility --routing flood --profile vehicle

Mobility, drone (15 m/s):
    python run_seeds.py --test mobility --routing opportunistic --profile drone
    python run_seeds.py --test mobility --routing flood --profile drone

Mobility with custom speed and turn pause:
    python run_seeds.py --test mobility --routing opportunistic --speed 1.4 --turn-pause 5

Battery consumption, WOR/CAD sleep enabled:
    python run_seeds.py --test energy --routing opportunistic --sleep
    python run_seeds.py --test energy --routing flood --sleep

Battery consumption without sleep (always-awake comparison):
    python run_seeds.py --test energy --routing opportunistic
    python run_seeds.py --test energy --routing flood

Traffic loads (repeat EACH routing mode separately at different intervals):
    python run_seeds.py --test traffic --routing opportunistic --interval 60
    python run_seeds.py --test traffic --routing opportunistic --interval 30
    python run_seeds.py --test traffic --routing opportunistic --interval 10
    python run_seeds.py --test traffic --routing opportunistic --interval 5
    python run_seeds.py --test traffic --routing flood --interval 60
    python run_seeds.py --test traffic --routing flood --interval 30
    python run_seeds.py --test traffic --routing flood --interval 10
    python run_seeds.py --test traffic --routing flood --interval 5

Network density (repeat EACH routing mode at these repeater counts):
    python run_seeds.py --test density --routing opportunistic --repeaters 5
    python run_seeds.py --test density --routing opportunistic --repeaters 10
    python run_seeds.py --test density --routing opportunistic --repeaters 15
    python run_seeds.py --test density --routing opportunistic --repeaters 20
    python run_seeds.py --test density --routing flood --repeaters 5
    python run_seeds.py --test density --routing flood --repeaters 10
    python run_seeds.py --test density --routing flood --repeaters 15
    python run_seeds.py --test density --routing flood --repeaters 20

Single-run route diagnostics/save one seed's route diagrams:
    python run_seeds.py --test route --routing opportunistic --diagrams-seed 1
    python run_seeds.py --test route --routing flood --diagrams-seed 1



