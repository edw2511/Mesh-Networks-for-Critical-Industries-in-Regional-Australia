"""Run seeds 1..30 in separate Python processes and export one combined metrics.csv.
Use --help for test-specific options. Run from this experiment directory.
"""
import argparse, csv, json, math, os, shutil, statistics, subprocess, sys, tempfile
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
FOLDERS={'route':'01_route_selection_efficiency','traffic':'02_traffic_load',
         'density':'03_network_density','mobility':'04_mobility_management',
         'energy':'05_battery_consumption'}
HERE=ROOT  # Set to selected results directory after parsing.
TEST='selectable'
MODE='selectable'
P=argparse.ArgumentParser(description='30-seed LoRa experiment; original results preserved in test folders')
P.add_argument('--test',choices=tuple(FOLDERS),required=True)
P.add_argument('--routing',choices=['opportunistic','flood'],required=True)
P.add_argument('--seed-start',type=int,default=1)
P.add_argument('--seed-end',type=int,default=30)
P.add_argument('--minutes',type=float,default=None)
P.add_argument('--interval',type=float,default=None)
P.add_argument('--packets',type=int,default=None)
P.add_argument('--repeaters',type=int,default=None)
P.add_argument('--profile',choices=['walking','vehicle','drone'],default='walking')
P.add_argument('--speed',type=float,default=None)
P.add_argument('--turn-pause',type=float,default=5.0)
P.add_argument('--sample-ms',type=float,default=5000)
P.add_argument('--sleep',action='store_true',help='Enable WOR/CAD sleep; recommended for battery test')
P.add_argument('--max-route-diagrams',type=int,default=75)
P.add_argument('--diagrams-seed',type=int,default=None,help='Save route diagrams for one chosen seed (otherwise disabled to keep batch manageable)')
P.add_argument('--keep-seed-data',action='store_true',help='Retain each seed\'s CSVs and plots in data/per_seed/seed_XX/')
P.add_argument('--stop-on-error',action='store_true',help='Stop immediately if any seed fails')
a=P.parse_args()
TEST=a.test
MODE=a.routing
HERE=ROOT/('flooding' if MODE=='flood' else 'opportunistic')/FOLDERS[TEST]
DEFAULTS={
 'route': (12,30,100,5),'traffic':(30,10,150,5),'density':(20,30,100,15),
 'mobility':(60,30,500,5),'energy':(30,30,100,5),
}
for key,default in zip(('minutes','interval','packets','repeaters'),DEFAULTS[TEST]):
    if getattr(a,key) is None:setattr(a,key,default)
if a.seed_start<0 or a.seed_end<a.seed_start:P.error('Invalid seed range')
if a.minutes<=0 or a.interval<=0 or a.packets<1 or a.repeaters<5:P.error('minutes, interval and packets must be positive; repeaters >=5')
for name in ('data','plots','route diagrams'):(HERE/name).mkdir(exist_ok=True)
for old in (HERE/'data'/'metrics.csv', HERE/'data'/'failures.csv'):
    if old.exists():old.unlink()
records=[];failures=[]
for seed in range(a.seed_start,a.seed_end+1):
    print(f'[{MODE}/{TEST}] Seed {seed} of {a.seed_end}',flush=True)
    with tempfile.TemporaryDirectory(prefix=f'lora_{TEST}_{seed}_') as temp:
        work=Path(temp)
        cmd=[sys.executable,str(ROOT/'run_experiment.py'),'--test',TEST,'--routing',MODE,'--seed',str(seed),'--output-dir',str(work),
             '--minutes',str(a.minutes),'--interval',str(a.interval),'--packets',str(a.packets),
             '--repeaters',str(a.repeaters),'--max-route-diagrams',str(a.max_route_diagrams)]
        if TEST=='mobility':
            cmd+=['--profile',a.profile,'--turn-pause',str(a.turn_pause),'--sample-ms',str(a.sample_ms)]
            if a.speed is not None:cmd+=['--speed',str(a.speed)]
        if a.sleep:cmd+=['--sleep']
        if seed!=a.diagrams_seed:cmd+=['--no-route-diagrams']
        proc=subprocess.run(cmd,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        if proc.returncode!=0:
            failures.append({'seed':seed,'returncode':proc.returncode,'error':proc.stderr[-2000:]})
            print(f'  FAILED seed {seed}: {proc.stderr[-500:]}',file=sys.stderr,flush=True)
            if a.stop_on_error:break
            continue
        metric_path=work/'data'/'metrics.csv'
        if not metric_path.exists():
            failures.append({'seed':seed,'returncode':-1,'error':'Missing data/metrics.csv'})
            if a.stop_on_error:break
            continue
        with metric_path.open(newline='',encoding='utf-8-sig') as f:
            seed_rows=list(csv.DictReader(f))
        if len(seed_rows)!=1:
            failures.append({'seed':seed,'returncode':-2,'error':f'Expected 1 metrics row, got {len(seed_rows)}'})
            if a.stop_on_error:break
            continue
        row=seed_rows[0]
        row['seed']=str(seed)
        row['routing']=MODE
        records.append(row)
        if a.keep_seed_data:
            destination=HERE/'data'/'per_seed'/f'seed_{seed:02d}'
            destination.mkdir(parents=True,exist_ok=True)
            for sub in ('data','plots'):
                if (work/sub).exists():shutil.copytree(work/sub,destination/sub,dirs_exist_ok=True)
        if seed==a.diagrams_seed:
            target=HERE/'route diagrams'/f'seed_{seed:02d}'
            if (work/'route diagrams').exists():shutil.copytree(work/'route diagrams',target,dirs_exist_ok=True)
        print(f"  OK: {row.get('delivered_packets','?')}/{row.get('generated_packets','?')} packets",flush=True)

if records:
    fields=list(dict.fromkeys(k for r in records for k in r))
    with (HERE/'data'/'metrics.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(records)
if failures:
    with (HERE/'data'/'failures.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=['seed','returncode','error']);w.writeheader();w.writerows(failures)

# Summary statistics and 95% t-based confidence intervals (normal approximation if SciPy unavailable).
# The seed is the experimental unit, not an individual packet.
KEYS={
 'route':['packet_delivery_ratio','mean_latency_ms','repeater_transmissions_per_delivery','selected_route_hops','selected_route_cost'],
 'traffic':['packet_delivery_ratio','mean_latency_ms','repeater_transmissions_per_delivery'],
 'density':['packet_delivery_ratio','mean_latency_ms','repeater_transmissions_per_delivery'],
 'mobility':['packet_delivery_ratio','mean_latency_ms','diagnostic_route_changes','opportunistic_handovers','opportunistic_forced_handovers'],
 'energy':['packet_delivery_ratio','mean_latency_ms','repeater_battery_used_mAh','battery_used_per_delivery_mAh'],
}
def numeric(key):
    out=[]
    for r in records:
        try:
            v=float(r.get(key,''))
            if math.isfinite(v):out.append(v)
        except (ValueError,TypeError):pass
    return out
stats=[]
for key in KEYS[TEST]:
    vals=numeric(key)
    if not vals:continue
    n=len(vals);mean=statistics.mean(vals);sd=statistics.stdev(vals) if n>1 else 0.0
    try:
        from scipy.stats import t
        critical=float(t.ppf(.975,n-1)) if n>1 else float('nan')
    except ImportError:
        critical=2.045 if n==30 else 1.96
    half=critical*sd/math.sqrt(n) if n>1 else float('nan')
    stats.append({'metric':key,'n_seeds':n,'mean':mean,'std_dev':sd,'ci95_low':mean-half,'ci95_high':mean+half})
if stats:
    with (HERE/'data'/'summary.csv').open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(stats[0]));w.writeheader();w.writerows(stats)
    for stat in stats:
        key=stat['metric'];xs=[];ys=[]
        for r in records:
            try:v=float(r.get(key,''))
            except (ValueError,TypeError):continue
            if math.isfinite(v):xs.append(int(r['seed']));ys.append(v)
        if not xs:continue
        fig,ax=plt.subplots(figsize=(9,4.8))
        ax.plot(xs,ys,marker='o',markersize=3,linewidth=1)
        ax.axhline(stat['mean'],linestyle='--',linewidth=1,label=f"Mean = {stat['mean']:.4g}")
        if len(xs)>1 and math.isfinite(stat['ci95_low']):
            ax.axhspan(stat['ci95_low'],stat['ci95_high'],alpha=.13,label='95% CI for mean')
        ax.set(title=f'{TEST} / {MODE}: {key}',xlabel='Random seed',ylabel=key)
        ax.grid(alpha=.2);ax.legend();fig.tight_layout()
        fig.savefig(HERE/'plots'/f'{key}_by_seed.png',dpi=180);plt.close(fig)
print(f'Completed {len(records)}/{a.seed_end-a.seed_start+1} seeds. Metrics: data/metrics.csv; statistics: data/summary.csv')
if failures:print(f'{len(failures)} failed runs: data/failures.csv',file=sys.stderr)
if not records:sys.exit(1)
if failures:sys.exit(2)
