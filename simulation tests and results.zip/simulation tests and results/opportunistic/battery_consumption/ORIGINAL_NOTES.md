# Energy — opportunistic — 30-seed experiment

Run `python run_seeds.py` from this folder. It executes 30 independent Python subprocesses with seeds 1–30 and writes **one combined `data/metrics.csv` containing one row per successful seed**. `data/summary.csv` provides mean, standard deviation and approximate 95% confidence intervals for the test-specific metrics. Graphs appear in `plots/`.

## Recommended command

```powershell
python run_seeds.py --sleep
```

## CSV and graph instructions

Plot seed (X) against charge consumed (mAh), charge per delivery (mAh/packet), PDR and latency (Y). Use --sleep for WOR/CAD, then repeat without --sleep for an awake baseline; compare mean values with 95% CI error bars. Battery numbers are simulated charge, not hardware measurements.

`data/metrics.csv`: each row is a seed, `seed` is the replicate identifier, `routing` identifies the algorithm. Test-specific metrics are inherited from the original simulator's `run_test.py`. `data/summary.csv` columns: `metric`, `n_seeds`, `mean`, `std_dev`, `ci95_low`, `ci95_high`.

## Important controls

- `--seed-start 1 --seed-end 30`: inclusive seed range (defaults).
- `--diagrams-seed 1`: retain 75 route snapshots for seed 1 in `route diagrams/seed_01/`. Graphics are off for other seeds for batch performance.
- `--max-route-diagrams 75`: adjustable diagram limit; original 1536×752 and 3072×1505 resolution settings retained.
- `--keep-seed-data`: retain each run's detailed CSVs and plots in `data/per_seed/seed_XX/`; default discards intermediates to save space.
- `--minutes`, `--interval`, `--packets`, `--repeaters`: experiment settings. Keep these identical between routing modes.
- `--profile walking|vehicle|drone`, `--speed`, `--turn-pause`: mobility settings.
- `--sleep`: enable the WOR/CAD sleep simulation.

**Statistical caution:** Independent seeds sample random network traffic and/or node positions; they do not guarantee identical packet arrival schedules across routing algorithms because the simulator uses a shared random generator. Use equal seed lists and configuration parameters, but describe the design as repeated stochastic runs, not fully paired identical-traffic trials. Shortest-path/flooding diagnostics may include routes computed by shared route-visualisation logic. Full execution depends on SimPy and GUI/plotting dependencies.
