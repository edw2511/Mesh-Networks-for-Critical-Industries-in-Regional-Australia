package com.example.enddevicemonitor

import android.app.PendingIntent
import android.content.*
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.driver.UsbSerialDriver
import java.io.IOException
import java.util.concurrent.Executors
import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import android.location.Location
import androidx.compose.foundation.text.selection.SelectionContainer

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "SerialMonitor"
    }

    private lateinit var usbManager: UsbManager
    private var serialPort: UsbSerialPort? = null

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    private lateinit var locationCallback: LocationCallback

    private var latitude by mutableStateOf("--")

    private var longitude by mutableStateOf("--")

    private var altitude by mutableStateOf("--")

    private var speed by mutableStateOf("--")

    private var accuracy by mutableStateOf("--")

    private var gpsHexPayload by mutableStateOf("")
    private val ACTION_USB_PERMISSION =
        "com.example.enddevicemonitor.USB_PERMISSION"

    private val logList = mutableStateListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        usbManager = getSystemService(USB_SERVICE) as UsbManager

        fusedLocationClient =
            LocationServices.getFusedLocationProviderClient(this)

        registerReceiver(
            usbReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            RECEIVER_NOT_EXPORTED
        )

        if (
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {

            ActivityCompat.requestPermissions(

                this,

                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),

                100

            )

        } else {

            startGps()

        }

        setContent {

            SerialMonitorUI(

                logs = logList,

                latitude = latitude,

                longitude = longitude,

                altitude = altitude,

                speed = speed,

                accuracy = accuracy,

                gpsHexPayload = gpsHexPayload,

                onSend = { sendCommand(it) },

                onSendGps = { sendGpsPacket() }

            )

        }

        detectDevice()
    }

    private fun detectDevice() {

        Log.d(TAG, "Searching for USB devices...")
        log("Searching for USB devices...")

        val deviceList = usbManager.deviceList

        Log.d(TAG, "USB devices found: ${deviceList.size}")
        log("USB devices found: ${deviceList.size}")

        deviceList.values.forEach { device ->

            val info = """
            Device:
            Name=${device.deviceName}
            VID=${device.vendorId}
            PID=${device.productId}
            Interfaces=${device.interfaceCount}
            """.trimIndent()

            Log.d(TAG, info)
            log(info)
        }

        val availableDrivers =
            UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)

        Log.d(TAG, "USB Serial Drivers Found = ${availableDrivers.size}")
        log("USB Serial Drivers Found = ${availableDrivers.size}")

        if (availableDrivers.isEmpty()) {
            log("No USB serial device found")
            return
        }

        val driver = availableDrivers[0]

        Log.d(TAG, "Using driver: ${driver.javaClass.simpleName}")
        log("Using driver: ${driver.javaClass.simpleName}")

        if (usbManager.hasPermission(driver.device)) {

            log("Permission already granted")

            openConnection(driver.device)

        } else {

            log("Requesting USB permission")

            requestPermission(driver.device)

        }
    }

    private fun requestPermission(device: UsbDevice) {
        val permissionIntent = PendingIntent.getBroadcast(
            this,
            0,
            Intent(ACTION_USB_PERMISSION),
            PendingIntent.FLAG_IMMUTABLE
        )

        usbManager.requestPermission(device, permissionIntent)
    }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            log("USB Broadcast received")
            if (intent?.action == ACTION_USB_PERMISSION) {

                synchronized(this) {

                    val device: UsbDevice? =
                        intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)

                    val granted =
                        intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)

                    if (granted && device != null) {
                        openConnection(device)
                    } else {
                        log("USB permission denied")
                    }
                }
            }
        }
    }

    private fun openConnection(device: UsbDevice) {

        val connection = usbManager.openDevice(device)
        Log.d(TAG, "USB connection = $connection")
        log("USB connection = $connection")

        if (connection == null) {
            log("Failed to open USB connection")
            return
        }

        val drivers = UsbSerialProber.getDefaultProber()
            .findAllDrivers(usbManager)
        Log.d(TAG, "probeDevice returned: $drivers")
        log("Drivers returned: ${drivers.size}")

        if (drivers.isEmpty()) {
            log("No USB serial drivers found")
            return
        }

        log("Drivers found: ${drivers.size}")

        for (driver in drivers) {

            log("Trying driver: ${driver.javaClass.simpleName}")

            for (port in driver.ports) {

                try {
                    log("Trying port $port")

                    port.open(connection)

                    port.setParameters(
                        115200,
                        8,
                        UsbSerialPort.STOPBITS_1,
                        UsbSerialPort.PARITY_NONE
                    )
                    port.dtr = true
                    port.rts = true

                    log("DTR enabled")
                    log("RTS enabled")

                    serialPort = port

                    log("SUCCESS: Connected on port $port")

                    startReading(port)

                    return

                } catch (e: Exception) {
                    log("Port failed: ${e.message}")
                }
            }
        }

        log("No working serial port found")
    }

    private fun startReading(port: UsbSerialPort) {
        Log.d(TAG, "startReading() called")
        log("startReading() called")
        val executor = Executors.newSingleThreadExecutor()

        executor.submit {

            val buffer = ByteArray(1024)

            log("RX thread started")

            while (true) {
                try {
                    val len = port.read(buffer, 1000)

                    if (len > 0) {

                        val rawBytes = buffer.copyOf(len)

                        log("Received $len bytes")

                        val data = String(rawBytes)

                        log("RX Text: $data")

                    }

                } catch (e: Exception) {
                    log("Disconnected: ${e.message}")
                    break
                }
            }
        }
    }

    private fun sendCommand(command: String) {

        if (serialPort == null) {
            log("ERROR: Serial port not connected.")
            return
        }

        try {

            val bytes = (command + "\r\n").toByteArray()

            serialPort!!.write(bytes, 1000)

            log("Sent ${bytes.size} bytes")
            log("TX: $command")

        } catch (e: Exception) {
            log("Send failed: ${e.message}")
        }
    }

    private fun buildGpsPayload(): String {

        val gpsText = "$latitude,$longitude"

        val payload = gpsText
            .toByteArray(Charsets.UTF_8)
            .joinToString("") { byte ->
                "%02X".format(byte.toInt() and 0xFF)
            }

        gpsHexPayload = payload

        return payload
    }

    private fun sendGpsPacket() {

        if (latitude == "--" || longitude == "--") {
            log("ERROR: GPS location is not available yet.")
            return
        }

        val payload = buildGpsPayload()

        val command = "AT+SEND=FFFE,0,$payload,06"

        log("GPS position: $latitude,$longitude")
        log("GPS hex payload: $payload")

        sendCommand(command)
    }

    private fun log(message: String) {
        runOnUiThread {
            logList.add(message)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(usbReceiver)
        serialPort?.close()
    }

    private fun startGps() {

        val request =
            LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                1000
            ).build()

        locationCallback =
            object : LocationCallback() {

                override fun onLocationResult(result: LocationResult) {

                    val location = result.lastLocation ?: return

                    latitude =
                        "%.6f".format(location.latitude)

                    longitude =
                        "%.6f".format(location.longitude)

                    altitude =
                        "%.2f".format(location.altitude)

                    speed =
                        "%.2f".format(location.speed)

                    accuracy =
                        "%.1f".format(location.accuracy)

                }

            }

        fusedLocationClient.requestLocationUpdates(

            request,

            locationCallback,

            mainLooper

        )

    }

    override fun onRequestPermissionsResult(

        requestCode: Int,

        permissions: Array<out String>,

        grantResults: IntArray

    ) {

        super.onRequestPermissionsResult(

            requestCode,

            permissions,

            grantResults

        )

        if (

            requestCode == 100 &&

            grantResults.isNotEmpty() &&

            grantResults[0] == PackageManager.PERMISSION_GRANTED

        ) {

            startGps()

        }

    }
}

@Composable
fun SerialMonitorUI(
    logs: List<String>,

    latitude: String,

    longitude: String,

    altitude: String,

    speed: String,

    accuracy: String,

    gpsHexPayload: String,

    onSend: (String) -> Unit,

    onSendGps: () -> Unit
) {

    var input by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {

        Text("RAK3172 Serial Monitor", style = MaterialTheme.typography.titleLarge)

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {

            Column(
                Modifier.padding(12.dp)
            ) {

                Text("Phone GPS")

                Text("Latitude : $latitude")

                Text("Longitude: $longitude")

                Text("Altitude : $altitude m")

                Text("Speed    : $speed m/s")

                Text("Accuracy : $accuracy m")

                Spacer(
                    modifier = Modifier.height(8.dp)
                )

                Text("Hex GPS Payload")

                SelectionContainer {
                    Text(
                        text = gpsHexPayload.ifEmpty { "No payload generated yet" }
                    )
                }

                Button(
                    onClick = {
                        onSendGps()
                    }
                ) {
                    Text("Generate GPS Payload")
                }

            }

        }

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(logs) { line ->
                Text(line)
            }
        }

        Row {

            TextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("AT command...") }
            )

            Button(onClick = {
                onSend(input)
                input = ""
            }) {
                Text("Send")
            }
        }
    }
}


