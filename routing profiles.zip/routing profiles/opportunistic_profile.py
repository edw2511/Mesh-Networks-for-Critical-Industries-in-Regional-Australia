"""Pasteable opportunistic routing profile for the original LoRa Mesh Simulator.

# SOURCE: adapted from the uploaded modified simulator. This adapter uses
# existing radio/WOR/PHY functions and installs added route logic before nodes.
# ROUTING TYPE: use install_profile(sim, routing_type='opportunistic').

Extracted and adapted from LMSim_opportunistic(1).zip, rather than a new
independent simulator.  Install this *before* constructing simulation nodes:

    import loraMeshSimulator as sim
    from opportunistic_profile import install_profile
    profile = install_profile(sim, routing_type='opportunistic')

Alternatively, paste the complete code below at the END of the original
loraMeshSimulator.py, then append these lines after it (before your driver
constructs nodes):

    import sys
    ROUTING_TYPE = 'opportunistic'  # or 'native', 'flood', 'shortest_hop', 'weighted'
    profile = install_profile(sys.modules[__name__], routing_type=ROUTING_TYPE)

The driver can expose the required switch using argparse:

    parser.add_argument('--routing-type', choices=['native', 'flood',
                        'shortest_hop', 'weighted', 'opportunistic'],
                        default='opportunistic')
    profile = install_profile(sim, routing_type=args.routing_type)

Only DATA_up forwarding is switched.  The original simulation continues to
model packet airtime, simultaneous receptions, SF/frequency/capture collisions,
WOR/CAD, physical RX availability and energy accounting.  This adapter patches
methods at runtime, without replacing the source of those radio models.

IMPORTANT ACCURACY NOTES
------------------------
* Defaults reproduce the modified simulator's *implemented* route-cost terms:
  hop=1.0, ETX=1.4, airtime=0.025 per ms, nonlinear battery=0.3, expected
  CAD wake delay=0.002 per ms.  Geographic distance is implicit in path loss;
  there is NO separate distance penalty by default.
* The thesis Chapter 4's proposed *linear* battery term can be requested with
  battery_model='linear'.  Its distance penalty can be requested with
  distance_weight=0.2.  These options change the experimental model and SHOULD
  NOT be presented as the settings of the uploaded LMSim_opportunistic.zip.
* The simulated receiver still applies the original sensitivity and collision
  rules, NOT a random Bernoulli draw from the routing probability.  Thus the
  logistic model is a route-ranking proxy, not a measured PRR or calibrated PHY.
* Sensor aggregation remains LOCAL; this file does not transmit aggregation
  records as LoRa packets.  The proposed 8-byte header is likewise NOT inserted
  into the original LoRa packet format.
* To vary attenuation at runtime, edit profile.extra_loss_db and call
  profile.refresh_mobile_links().  Create all nodes, then call sim.networkConfig()
  before running any end-device process.

This adapter was syntax-checked and its route calculations unit-tested against
mock simulator state.  Full discrete-event integration requires SimPy and the
original simulator's runtime dependencies; compare delivery outputs against the
uploaded modified version before citing numerical experimental results.
"""

# No __future__ import: this entire file can also be pasted at the END of
# loraMeshSimulator.py without violating Python's future-import ordering.

from collections import defaultdict, deque
from dataclasses import dataclass
import heapq
import math
import random
from typing import Any


# Selectable routing profiles: only DATA_up forwarding is changed.
ROUTING_TYPES = ('native', 'flood', 'shortest_hop', 'weighted', 'opportunistic')


@dataclass
class ProfileParameters:
    """Coefficients and protocol controls added by the routing profile."""
    max_candidates: int = 3              # Maximum prioritised receivers
    hop_weight: float = 1.0             # Per-link fixed penalty
    etx_weight: float = 1.4             # One-way ETX = 1 / PRR
    airtime_weight: float = 0.025       # 1/ms, multiplying Tpacket / PRR
    energy_weight: float = 0.3          # Receiving repeater's battery penalty
    distance_weight: float = 0.0        # Not present in uploaded modified code
    wake_weight: float = 0.002          # 1/ms, estimated CAD waiting time
    rssi_transition_db: float = 6.0     # Shape of heuristic RSSI-to-PRR mapping
    hysteresis: float = 0.12            # Fractional improvement required (12%)
    dwell_ms: float = 120000.0          # Minimum normal-route-switch interval
    guard_ms: float = 50.0             # Safety gap beyond a DATA packet airtime
    jitter_ms: float = 10.0            # Random candidate timer perturbation
    max_forwards: int = 12             # Forwarding limit; in-memory not on-air TTL
    suppression_enabled: bool = True   # Cancel queued candidate after overhearing
    battery_model: str = 'nonlinear'    # 'linear' is the Chapter 4 alternative
    # The modified code uses SF7, CR index 2, 20-byte DATA for route costing.
    cost_sf: int = 7
    cost_cr: int = 2
    cost_payload_bytes: int = 20


# Graph-based link assessment and preferred-route selection.
class OpportunisticRouter:
    """Globally informed graph model for selective DATA_up forwarding."""

    def __init__(self, profile: 'RoutingProfile'):
        self.profile = profile
        self.routes: dict[int, list[int]] = {}       # Source -> preferred node IDs
        self.last_switch: dict[int, float] = {}      # Source -> last handover time

    @property
    def sim(self):
        return self.profile.sim

    def gateways(self):
        """Return physical IDs of available gateways."""
        return [n.id for n in self.sim.nodes
                if n.type.lower() == 'gw' and getattr(n, 'available', True)]

    def link_probability(self, a: int, b: int) -> float:
        """Map RSSI minus sensitivity to a heuristic PRR, as in modified code.

        Return zero below sensitivity or for unavailable/invalid endpoints.
        This is the ROUTING estimate; actual packet loss remains native.
        """
        s = self.sim
        if a == b or not (0 <= a < len(s.nodes) and 0 <= b < len(s.nodes)):
            return 0.0
        tx, rx = s.nodes[a], s.nodes[b]
        if tx.type.lower() == 'gw' or not getattr(tx, 'available', True) \
                or not getattr(rx, 'available', True):
            return 0.0
        distance = max(math.hypot(tx.x-rx.x, tx.y-rx.y), 0.001)
        loss = (s.Lpld0 + 10.0*s.gamma*math.log10(distance/s.d0)
                + self.profile.extra_link_loss(a,b))
        power = s.Ptx / 2.0 if tx.type.lower() == 'ed' else s.Ptx
        rssi = power - s.GL - loss
        if rssi < float(s.minsensi):
            return 0.0
        margin = max(-60.0, min(60.0, rssi-float(s.minsensi)))
        return 1.0/(1.0+math.exp(-margin/self.profile.params.rssi_transition_db))

    def battery_penalty(self, receiver: Any) -> float:
        """Energy heuristic of uploaded code or optional Chapter 4 linear term."""
        if receiver.type.lower() == 'gw':
            return 0.0
        percent = max(0.0, min(100.0, float(receiver.batteryPercentage)))
        if self.profile.params.battery_model == 'linear':
            return 1.0-percent/100.0
        if self.profile.params.battery_model == 'nonlinear':
            return 100.0/max(1.0, percent)-1.0
        raise ValueError('battery_model must be linear or nonlinear')

    def edge_cost(self, a: int, b: int) -> float:
        """Weighted non-negative cost of directed link a -> b."""
        s, pms = self.sim, self.profile.params
        if s.nodes[b].type.lower() not in ('rp', 'gw'):
            return math.inf
        p = self.link_probability(a,b)
        if p <= 0.0:
            return math.inf
        _, rx = s.nodes[a], s.nodes[b]
        packet_ms = sum(s.airtime(pms.cost_sf, pms.cost_cr,
                                  pms.cost_payload_bytes, s.bw))
        # Add the intended sleep/CAD wait penalty, not actual elapsed delay.
        wake_ms = (rx.cadPeriodity/2.0 if rx.mode in ('SLEEP','CAD') else 0.0)
        separation = math.hypot(s.nodes[a].x-rx.x, s.nodes[a].y-rx.y)
        dist_norm = separation/max(float(s.maxDist),0.001)
        return (pms.hop_weight + pms.etx_weight/p
                + pms.airtime_weight*packet_ms/p
                + pms.energy_weight*self.battery_penalty(rx)
                + pms.wake_weight*wake_ms
                + pms.distance_weight*dist_norm)

    def downstream(self, gateway: int) -> dict[int,float]:
        """Reverse Dijkstra: minimum remaining cost from each node to gateway."""
        s = self.sim
        if gateway not in self.gateways():
            return {}
        costs = {gateway:0.0}
        pq = [(0.0,gateway)]
        while pq:
            cost, at = heapq.heappop(pq)
            if cost > costs[at]+1e-9:
                continue
            for n in s.nodes:
                if n.id == at or n.type.lower() not in ('ed','rp'):
                    continue
                edge = self.edge_cost(n.id,at)
                candidate = cost+edge
                if math.isfinite(candidate) and candidate < costs.get(n.id,math.inf):
                    costs[n.id] = candidate
                    heapq.heappush(pq,(candidate,n.id))
        return costs

    def best_path(self, source: int, gateway: int) -> list[int]:
        """Reconstruct preferred source-to-gateway path from Dijkstra costs."""
        s = self.sim
        remaining = self.downstream(gateway)
        if source not in remaining:
            return []
        path, visited = [source],{source}
        while path[-1] != gateway and len(path) <= len(s.nodes):
            current = path[-1]
            options = [
                (self.edge_cost(current,n.id)+remaining.get(n.id,math.inf),n.id)
                for n in s.nodes if n.id not in visited and
                (n.type.lower()=='rp' or n.id==gateway) and
                math.isfinite(self.edge_cost(current,n.id))
            ]
            if not options:
                return []
            _, nxt = min(options)
            if remaining.get(nxt,math.inf) >= remaining.get(current,math.inf):
                return []
            path.append(nxt)
            visited.add(nxt)
        return path if path[-1] == gateway else []

    def path_cost(self,path: list[int]) -> float:
        """Sum all constituent directed link costs."""
        return sum(self.edge_cost(a,b) for a,b in zip(path,path[1:])) if path else math.inf

    def choose_path(self,source: int,gateway: int,now: float) -> list[int]:
        """Allow a 12%-better route after dwell; force repair if route broken."""
        proposed = self.best_path(source,gateway)
        previous = self.routes.get(source,[])
        previous_cost = self.path_cost(previous)
        proposed_cost = self.path_cost(proposed)
        if not previous or not math.isfinite(previous_cost):
            if previous and proposed != previous:
                self.profile.stats['forced_handovers'] += 1
            self.routes[source] = proposed
            self.last_switch[source] = now
            if previous != proposed:
                self.profile.experiment_event('route_change',source=source,
                     old_route=str(previous),new_route=str(proposed))
        elif (proposed and proposed != previous and
              now-self.last_switch.get(source,-math.inf)>=self.profile.params.dwell_ms and
              proposed_cost < (1.0-self.profile.params.hysteresis)*previous_cost):
            self.routes[source] = proposed
            self.last_switch[source] = now
            self.profile.stats['handovers'] += 1
            self.profile.experiment_event('route_change',source=source,
                 old_route=str(previous),new_route=str(proposed))
        return self.routes.get(source,[])

    def candidates(self,sender: int,origin: int,gateway: int) -> list[int]:
        """Rank at most K receivers by route preference and progress to GW."""
        s = self.sim
        remaining = self.downstream(gateway)
        here = remaining.get(sender,math.inf)
        path = self.routes.get(origin,[])
        preferred = None
        if sender in path and path.index(sender)+1 < len(path):
            preferred = path[path.index(sender)+1]
        options = [n.id for n in s.nodes if n.id != sender and
                   (n.type.lower()=='rp' or n.id==gateway) and
                   math.isfinite(self.edge_cost(sender,n.id)) and
                   remaining.get(n.id,math.inf) < here]
        options.sort(key=lambda nid:(nid!=preferred,
                     self.edge_cost(sender,nid)+remaining[nid],nid))
        return options[:self.profile.params.max_candidates]

    def all_routes(self,source: int,gateway: int,limit: int=10000) -> list[list[int]]:
        """Enumerate simple feasible routes only for small-network diagnostics."""
        routes=[]
        def walk(at,path):
            if len(routes)>=limit:
                return
            if at==gateway:
                routes.append(path)
                return
            for n in self.sim.nodes:
                if n.id not in path and (n.type.lower()=='rp' or n.id==gateway) and \
                        math.isfinite(self.edge_cost(at,n.id)):
                    walk(n.id,path+[n.id])
        walk(source,[source])
        return sorted(routes,key=self.path_cost)

    def hop_edge_cost(self,a: int,b: int) -> float:
        """Unit cost for reachable links, used by the shortest-hop baseline."""
        return 1.0 if self.link_probability(a,b)>0 else math.inf

    def shortest_hop_path(self,source: int,gateway: int) -> list[int]:
        """Breadth-first search, one edge per hop."""
        todo=deque([[source]])
        visited={source}
        while todo:
            path=todo.popleft()
            at=path[-1]
            if at==gateway:
                return path
            for n in self.sim.nodes:
                if n.id in visited or n.type.lower() not in ('rp','gw'):
                    continue
                if not math.isfinite(self.hop_edge_cost(at,n.id)):
                    continue
                visited.add(n.id)
                todo.append(path+[n.id])
        return []


# Per-experiment state, candidate timers, suppression, mobility and logging.
class RoutingProfile:
    """Holds state, logger and route/forward/suppression adapter methods."""

    def __init__(self,sim: Any,routing_type: str='opportunistic',
                 params: ProfileParameters | None=None):
        if routing_type not in ROUTING_TYPES:
            raise ValueError(f'Unknown routing_type={routing_type!r}; expected {ROUTING_TYPES}')
        self.sim=sim
        self.routing_type=routing_type
        self.params=params if params is not None else ProfileParameters()
        if self.params.rssi_transition_db<=0 or self.params.max_candidates<1:
            raise ValueError('rssi_transition_db must be positive; max_candidates >= 1')
        if not 0 <= self.params.hysteresis < 1:
            raise ValueError('hysteresis is a FRACTION between 0 and 1')
        self.extra_loss_db: dict[tuple[int,int],float] = {}
        self.stats=defaultdict(int)                 # Count suppression/relay/handover
        self.traces=defaultdict(list)               # Packet ID -> forwarders
        self.events=[]                             # Diagnostic route and radio events
        self.visual_forward_parents=defaultdict(dict) # packet -> repeater -> prior hop
        self.visual_gateway_parents=defaultdict(dict) # packet -> GW -> prior hop
        self.visual_candidates=defaultdict(dict)     # packet -> candidate rank/status
        self.visual_suppressed=defaultdict(set)     # packet -> cancelled node IDs
        self.visual_delivered=set()                # packets confirmed by gateway
        self.visual_events=defaultdict(list)       # optional event reconstruction
        self.visual_artists=[]                    # artist handles for optional overlay
        self.show_routing_overlay=False            # manual opt-in; no extra plot overhead
        self.router=OpportunisticRouter(self)
        self._patched=False

    def experiment_event(self,event: str,**fields):
        """Timestamp and record a new simulation event without radio overhead."""
        self.events.append(dict(time_ms=float(self.sim.env.now),event=event,**fields))

    def visual_event(self, seqNr: str, event_type: str, **fields):
        """Record a packet-specific event for optional route visualisation."""
        self.visual_events[seqNr].append(dict(time_ms=float(self.sim.env.now),
                                              event=event_type,**fields))

    def clear_routing_overlay(self):
        """Remove only artists created by this profile's optional overlay."""
        for artist in self.visual_artists:
            try:
                artist.remove()
            except (ValueError,NotImplementedError):
                pass
        self.visual_artists.clear()

    def reconstruct_packet_path(self, seqNr: str, gateway_id: int | None=None):
        """Rebuild observed forwarding sequence from predecessor records."""
        source=int(seqNr.split('|',1)[0])
        parents=self.visual_forward_parents.get(seqNr,{})
        last=(self.visual_gateway_parents.get(seqNr,{}).get(gateway_id)
              if gateway_id is not None else None)
        if last is None:
            if not parents:
                return [source]
            last=next(reversed(parents))
        path=[last]
        seen={last}
        while path[-1]!=source:
            previous=parents.get(path[-1])
            if previous is None or previous in seen:
                break
            path.append(previous)
            seen.add(previous)
        path=list(reversed(path))
        return path+[gateway_id] if gateway_id is not None else path

    def draw_routing_overlay(self,seqNr: str):
        """Optionally draw preferred/observed routes on existing matplotlib axes.

        Does NOT create a new graph or change any packet timings.  Invoke
        after a delivery if the driver enables profile.show_routing_overlay.
        """
        s=self.sim
        if not self.show_routing_overlay or not getattr(s,'graphics',False) \
                or not hasattr(s,'ax'):
            return
        self.clear_routing_overlay()
        source=int(seqNr.split('|',1)[0])
        preferred=self.router.routes.get(source,[])
        gateways=self.router.gateways()
        gw=gateways[0] if gateways else None
        observed=self.reconstruct_packet_path(
            seqNr, gw if seqNr in self.visual_delivered else None)
        for path,color,style,width in ((preferred,'royalblue','--',2.5),
                                       (observed,'limegreen','-',3.5)):
            for a,b in zip(path,path[1:]):
                line,=s.ax.plot([s.nodes[a].x,s.nodes[b].x],
                                [s.nodes[a].y,s.nodes[b].y],
                                color=color,linestyle=style,linewidth=width)
                self.visual_artists.append(line)

    def extra_link_loss(self,a: int,b: int) -> float:
        """Optional directed excess attenuation in dB, used in degradation tests."""
        return self.extra_loss_db.get((a,b),0.0)

    def refresh_mobile_links(self,moving_node_id: int | None=None):
        """Recompute native packet templates and neighbour measurements after movement.

        The original simulator precomputes distances and myPacket.rssi when
        networkConfig() runs.  Updating only x/y would otherwise leave PHY
        connectivity stale.  This repairs the cached geometry and packet RSSI.
        """
        s=self.sim
        for n in s.nodes:
            n.dist=[math.hypot(n.x-r.x,n.y-r.y) for r in s.nodes]
            n.neighbor_ids=[r.id for r in s.nodes if r.id != n.id and
                 n.type.lower()!='ed' and r.type.lower()!='ed' and
                 n.dist[r.id] <= s.maxDist]
            # No random perturbation in the refreshed neighbour distance map.
            n.neighbor_rssi=[(s.Ptx-s.GL-s.Lpld0-
                  10*s.gamma*math.log10(max(n.dist[r.id],.001)/s.d0))
                  if r.id in n.neighbor_ids else 0.0 for r in s.nodes]
            for pk in getattr(n,'packet',[]):
                if pk.rxNodeId==n.id:
                    continue
                distance=max(n.dist[pk.rxNodeId],.001)
                pl=s.Lpld0+10*s.gamma*math.log10(distance/s.d0)
                pk.rssi=pk.ptx-s.GL-pl-self.extra_link_loss(n.id,pk.rxNodeId)
                pk.lost=pk.rssi<float(s.sensi[pk.sf-7][s.bw_index[pk.bw]])
        if moving_node_id is not None:
            self.stats['topology_refreshes']+=1
            node=s.nodes[moving_node_id]
            if node.type.lower()=='ed' and self.router.gateways():
                self.router.choose_path(node.id,self.router.gateways()[0],s.env.now)

    def collect_sensor(self,node: Any,value: float):
        """Append a LOCAL sensor sample at a repeater (not transmitted)."""
        if node.type.lower()=='rp':
            node.sensorSamples.append(float(value))

    def aggregate_sensor(self,node: Any):
        """Return count and arithmetic mean of local samples, then reset."""
        if not node.sensorSamples:
            return None
        values=node.sensorSamples
        result=dict(node=node.id,count=len(values),mean=sum(values)/len(values))
        node.sensorSamples=[]
        return result

    def observe(self,node: Any,seqNr: str,transmitter: int):
        """Suppress a pending lower-ranked candidate after confirmed overhearing."""
        pending=node.opPending.get(seqNr)
        if pending is None or self.routing_type!='opportunistic' or \
                not self.params.suppression_enabled:
            return
        gw=pending['gateway']
        remaining=self.router.downstream(gw)
        if remaining.get(transmitter,math.inf)<remaining.get(node.id,math.inf):
            if not pending['cancelled']:
                pending['cancelled']=True
                self.stats['suppressed']+=1
                self.visual_suppressed[seqNr].add(node.id)
                self.visual_event(seqNr,'suppressed',node=node.id,
                                  overheard_transmitter=transmitter)
                if node.id in self.visual_candidates.get(seqNr,{}):
                    self.visual_candidates[seqNr][node.id]['status']='suppressed'
                self.experiment_event('suppressed',node=node.id,packet_id=seqNr,
                                      overheard_transmitter=transmitter)

    def experimental_repeat(self,node: Any,env: Any,packet: Any,seqNr: str,prevRp: int):
        """Non-opportunistic DATA_up modes: flood, shortest_hop and weighted."""
        if self.routing_type=='opportunistic':
            return
        yield from self._profile_repeat(node,env,packet,seqNr,prevRp)

    def opportunistic_repeat(self,node: Any,env: Any,packet: Any,seqNr: str,prevRp: int):
        """Rank candidates with timers and suppress overheard backup relays."""
        if self.routing_type!='opportunistic':
            return
        yield from self._profile_repeat(node,env,packet,seqNr,prevRp)

    def op_observe(self,node: Any,seqNr: str,transmitter: int):
        """Alias matching the modified simulator's original function name."""
        return self.observe(node,seqNr,transmitter)

    def _profile_repeat(self,node: Any,env: Any,packet: Any,seqNr: str,prevRp: int):
        """SimPy process for flood/shortest-hop/weighted/opportunistic relay."""
        if not getattr(node,'available',True) or seqNr in node.opForwarded:
            return
        try:
            origin=int(seqNr.split('|',1)[0])
        except (ValueError,IndexError):
            return
        gws=self.router.gateways()
        if not gws:
            self.stats['no_gateway']+=1
            return
        # Uploaded profile uses a gateway selected by downstream cost of sender.
        gw=min(gws,key=lambda gid:self.router.downstream(gid).get(prevRp,math.inf))
        mode=self.routing_type
        if mode!='opportunistic':
            if mode=='flood':
                node.nextRp=-1        # Broadcast using native createPackets()
                delay=random.uniform(0,100)
            else:
                path=(self.router.shortest_hop_path(origin,gw) if mode=='shortest_hop'
                      else self.router.choose_path(origin,gw,env.now))
                if node.id not in path:
                    return
                index=path.index(node.id)
                if index==0 or index+1>=len(path) or path[index-1]!=prevRp:
                    return
                node.nextRp=path[index+1]
                delay=0.0
            node.opForwarded.add(seqNr)
            yield env.timeout(delay)
            if not getattr(node,'available',True):
                return
            with node.nTransmitters.request() as req:
                yield req
                if not getattr(node,'available',True):
                    return
                self.stats['relay_attempts']+=1
                self.traces[seqNr].append(node.id)
                self.visual_forward_parents[seqNr][node.id]=prevRp
                self.visual_event(seqNr,'forward_attempt',node=node.id,previous_hop=prevRp)
                self.experiment_event('forward_attempt',node=node.id,packet_id=seqNr,
                                      previous_hop=prevRp,algorithm=mode)
                # The original repeat() supplies the actual radio TX/backoff.
                yield env.process(node.repeat(env,seqNr,prevRp))
            return

        if seqNr in node.opPending:
            return
        choices=self.router.candidates(prevRp,origin,gw)
        self.experiment_event('candidate_list',node=node.id,packet_id=seqNr,
                              candidate_count=len(choices))
        if node.id not in choices:
            self.stats['not_candidate']+=1
            return
        rank=choices.index(node.id)
        self.visual_candidates[seqNr][node.id]=dict(rank=rank,
            status='pending',previous_hop=prevRp,time_ms=env.now)
        self.visual_event(seqNr,'candidate_pending',node=node.id,rank=rank)
        Tpre,Tpay=self.sim.airtime(self.params.cost_sf,self.params.cost_cr,
                                   self.params.cost_payload_bytes,self.sim.bw)
        slot=max(float(packet.rectime),Tpre+Tpay)+self.params.guard_ms
        state=dict(cancelled=False,gateway=gw,rank=rank)
        node.opPending[seqNr]=state
        node.extendRxIdleDeadline(env)
        self.stats['eligible_receptions']+=1
        try:
            # Lower rank has extra wait slot to permit overhearing of priority RX.
            yield env.timeout(rank*slot+random.uniform(0,self.params.jitter_ms))
            if state['cancelled'] or seqNr in node.opForwarded:
                return
            if node.id not in self.router.candidates(prevRp,origin,gw):
                self.stats['candidate_changed']+=1
                return
            next_choices=self.router.candidates(node.id,origin,gw)
            if not next_choices:
                self.stats['dead_end']+=1
                return
            node.nextRp=next_choices[0]
            with node.nTransmitters.request() as req:
                yield req
                if state['cancelled'] or seqNr in node.opForwarded:
                    return
                if len(self.traces[seqNr])>=self.params.max_forwards:
                    self.stats['ttl_drops']+=1
                    return
                node.opForwarded.add(seqNr)
                self.stats['relay_attempts']+=1
                self.traces[seqNr].append(node.id)
                self.visual_forward_parents[seqNr][node.id]=prevRp
                self.visual_event(seqNr,'forward_attempt',node=node.id,previous_hop=prevRp)
                self.experiment_event('forward_attempt',node=node.id,packet_id=seqNr,
                                      previous_hop=prevRp,rank=rank,algorithm=mode)
                yield env.process(node.repeat(env,seqNr,prevRp))
        finally:
            node.opPending.pop(seqNr,None)
            info=self.visual_candidates.get(seqNr,{}).get(node.id)
            if info is not None and info.get('status')=='pending':
                info['status']='withdrawn'
                self.visual_event(seqNr,'candidate_withdrawn',node=node.id)

    def _corrected_native_position_learning(self):
        """Repair original RP/GW compact-index bug before initial networkConfig.

        Original Graph uses compact infrastructure IDs, while neighbour_ids
        stores physical node IDs.  This version uses full node IDs throughout.
        Original WOR position-tree behaviour remains a shortest-distance tree.
        """
        s=self.sim
        infrastructure=[n for n in s.nodes if n.type.lower() in ('rp','gw')]
        if not infrastructure:
            return
        ids={n.id for n in infrastructure}
        adjacency={i:[] for i in ids}
        for n in infrastructure:
            for other in infrastructure:
                if other.id!=n.id:
                    d=math.hypot(n.x-other.x,n.y-other.y)
                    if d<=s.maxDist:
                        adjacency[n.id].append((other.id,d))
        gateways=[n.id for n in infrastructure if n.type.lower()=='gw']
        cost={nid:math.inf for nid in ids}
        next_hop={nid:-1 for nid in ids}
        nearest={nid:-1 for nid in ids}
        pq=[]
        for gw in gateways:
            cost[gw]=0.0; next_hop[gw]=gw; nearest[gw]=gw
            heapq.heappush(pq,(0.0,gw))
        while pq:
            distance,at=heapq.heappop(pq)
            if distance>cost[at]+1e-9:
                continue
            for previous,d in adjacency[at]:
                proposed=distance+d
                if proposed<cost[previous]-1e-9:
                    cost[previous]=proposed
                    next_hop[previous]=at
                    nearest[previous]=nearest[at]
                    heapq.heappush(pq,(proposed,previous))
        for n in infrastructure:
            n.distanceValue=cost[n.id]
            n.nextRp=next_hop[n.id]
            n.nextRpOriginal=next_hop[n.id]
            n.nearestGwId=nearest[n.id]
        for n in infrastructure:
            if n.type.lower()!='rp':
                continue
            at,hops,seen=n.id,0,set()
            while at not in gateways and at not in seen:
                seen.add(at)
                next_id=next_hop.get(at,-1)
                if next_id<0:
                    break
                at=next_id
                hops+=1
            n.syncLevel=hops
            n.worUpPacketHistory=deque([0]*(hops+2),maxlen=hops+2)

    def install(self):
        """Hook only the existing network/radio class at its extension points."""
        if self._patched:
            return self
        s=self.sim
        if getattr(s,'_opportunistic_profile_installed',False):
            raise RuntimeError('A routing profile is already installed on this simulator')
        s._opportunistic_profile_installed=True
        native_node_init=s.node.__init__
        native__receive=s.node._receive
        native_receive=s.node.receive
        native_transmit=s.node.transmit
        native_packet_init=s.myPacket.__init__
        native_can_receive=s.node.canReceivePacket
        native_pending=s.node.repeaterHasPendingWork
        profile=self

        # Per-node state exists before networkConfig() creates packet templates.
        def profile_node_init(node,env,x,y,type):
            native_node_init(node,env,x,y,type)
            node.available=True
            node.opPending={}                 # packet -> cancellable timer state
            node.opForwarded=set()             # local duplicate/forwarded cache
            node.sensorSamples=[]              # local-only sensor records
        s.node.__init__=profile_node_init

        # Do not model failed repeaters as available radio receivers.
        def can_receive(node):
            return bool(node.available) and native_can_receive(node)
        s.node.canReceivePacket=can_receive

        def pending_work(node):
            return bool(node.opPending) or native_pending(node)
        s.node.repeaterHasPendingWork=pending_work

        # Add scenario-specific directed excess path loss to the native packet.
        def packet_init(pk,*args,**kwargs):
            native_packet_init(pk,*args,**kwargs)
            extra=profile.extra_link_loss(pk.nodeid,pk.rxNodeId)
            if extra:
                pk.rssi-=extra
                pk.lost=pk.rssi<float(s.sensi[pk.sf-7][s.bw_index[pk.bw]])
        s.myPacket.__init__=packet_init

        # Preserve the native ED/GW receive handlers. Intercept RP DATA_up only
        # AFTER physical success and collision detection, which are unchanged.
        def patched__receive(node,env,packet,seqNr,prevDistanceValue,nextRp,prevRp):
            if profile.routing_type!='native' and node.type.lower()=='rp' and \
                    packet.packetType=='DATA_up':
                if not node.available or seqNr in node.opForwarded or seqNr in node.opPending:
                    return 0
                if seqNr not in node.recPackets:
                    node.recPackets.append(seqNr)
                profile.experiment_event('relay_receive',node=node.id,packet_id=seqNr,
                                         previous_hop=prevRp)
                handler=(profile.opportunistic_repeat if profile.routing_type=='opportunistic'
                         else profile.experimental_repeat)
                result=yield env.process(handler(node,env,packet,seqNr,prevRp))
                return result
            before=seqNr in s.packetsRecBS
            result=yield from native__receive(node,env,packet,seqNr,
                                            prevDistanceValue,nextRp,prevRp)
            if node.type.lower()=='gw' and packet.packetType=='DATA_up' and \
                    not before and seqNr in s.packetsRecBS:
                profile.stats['delivered']+=1
                profile.visual_delivered.add(seqNr)
                profile.visual_gateway_parents[seqNr][node.id]=prevRp
                profile.visual_event(seqNr,'gateway_delivery',gateway=node.id,
                                     previous_hop=prevRp)
                profile.draw_routing_overlay(seqNr)
                profile.experiment_event('gateway_delivery',node=node.id,packet_id=seqNr)
            return result
        s.node._receive=patched__receive

        # Once a higher-priority repeater's complete packet is decoded,
        # lower-priority pending candidates can cancel before transmission.
        def patched_receive(node,env,packet,seqNr,prevDistanceValue,nextRp,prevRp):
            if profile.routing_type=='opportunistic' and packet.packetType=='DATA_up' \
                    and node.type.lower()=='rp':
                profile.observe(node,seqNr,prevRp)
            result=yield from native_receive(node,env,packet,seqNr,
                                             prevDistanceValue,nextRp,prevRp)
            return result
        s.node.receive=patched_receive

        # Choose path when a mobile ED actually emits its DATA, not on WOR.
        def patched_transmit(node,env,seqNr=None):
            if not node.available:
                return
            current_packet=node.packet[0] if node.packet else None
            if current_packet and current_packet.packetType=='DATA_up':
                profile.experiment_event('data_tx',node=node.id,
                     packet_id=current_packet.seqNr,node_type=node.type)
                if node.type.lower()=='ed' and profile.routing_type!='native':
                    profile.stats['generated']+=1
                    gws=profile.router.gateways()
                    if gws:
                        profile.router.choose_path(node.id,gws[0],env.now)
            yield from native_transmit(node,env,seqNr)
        s.node.transmit=patched_transmit

        # Attach local aggregation methods used in aggregation experiment.
        def collect_sensor(node,value):
            return profile.collect_sensor(node,value)
        def aggregate_sensor(node):
            return profile.aggregate_sensor(node)
        s.node.collect_sensor=collect_sensor
        s.node.aggregate_sensor=aggregate_sensor

        # Original Graph mixes compact indices with IDs when EDs are inserted.
        # Install corrected pre-existing position-learning tree before config.
        s.run_position_learning=self._corrected_native_position_learning

        # Expose a familiar API so run drivers can use their existing calls.
        s.ROUTING_MODE=self.routing_type
        s.router=self.router
        s.op_stats=self.stats
        s.op_traces=self.traces
        s.EXPERIMENT_EVENTS=self.events
        s.LINK_EXTRA_LOSS_DB=self.extra_loss_db
        s.ROUTING_MODES=ROUTING_TYPES
        s.routing_mode=lambda: profile.routing_type
        s.OP_MAX_CANDIDATES=self.params.max_candidates
        s.OP_ETX_WEIGHT=self.params.etx_weight
        s.OP_HOP_WEIGHT=self.params.hop_weight
        s.OP_AIRTIME_WEIGHT=self.params.airtime_weight
        s.OP_ENERGY_WEIGHT=self.params.energy_weight
        s.OP_WAKE_WEIGHT=self.params.wake_weight
        s.OP_RSSI_TRANSITION_DB=self.params.rssi_transition_db
        s.OP_HYSTERESIS=self.params.hysteresis
        s.OP_DWELL_MS=self.params.dwell_ms
        s.OP_GUARD_MS=self.params.guard_ms
        s.OP_JITTER_MS=self.params.jitter_ms
        s.OP_TTL=self.params.max_forwards
        s.OP_SUPPRESSION_ENABLED=self.params.suppression_enabled
        s.OPPORTUNISTIC=self.routing_type=='opportunistic'
        s.visual_forward_parents=self.visual_forward_parents
        s.visual_gateway_parents=self.visual_gateway_parents
        s.visual_candidates=self.visual_candidates
        s.visual_suppressed=self.visual_suppressed
        s.visual_delivered=self.visual_delivered
        s.visual_events=self.visual_events
        s.visual_artists=self.visual_artists
        s.visual_event=self.visual_event
        s.extra_link_loss=self.extra_link_loss
        s.clear_routing_overlay=self.clear_routing_overlay
        s.reconstruct_packet_path=self.reconstruct_packet_path
        s.draw_routing_overlay=self.draw_routing_overlay
        s.refresh_mobile_links=self.refresh_mobile_links
        s.experiment_event=self.experiment_event
        self._patched=True
        return self


# Public installer: invoke before the first node is constructed.
def install_profile(sim: Any,routing_type: str='opportunistic',
                    params: ProfileParameters | None=None) -> RoutingProfile:
    """Single entry point: import simulator; install; then create nodes."""
    return RoutingProfile(sim,routing_type=routing_type,params=params).install()
