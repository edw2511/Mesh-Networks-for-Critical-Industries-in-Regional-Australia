"""Duplicate-suppressed flooding profile for the ORIGINAL LoRa Mesh Simulator.

This is a standalone, PASTABLE adapter, not a replacement for the underlying
radio/propagation simulation. It may be placed in ``flooding_profile.py`` next
to the original ``loraMeshSimulator.py``::

    import loraMeshSimulator as sim
    from flooding_profile import install_flooding_profile
    flood = install_flooding_profile(sim)
    # Create nodes and run networkConfig() only AFTER installing the profile.

Or paste the whole module at the END of the original ``loraMeshSimulator.py``
and then call, from the simulation driver (before creating nodes)::

    import loraMeshSimulator as sim
    sim.install_flooding_profile(sim)

Only successfully received repeater DATA_up packets are intercepted; the
original simulator continues handling packet airtime, collisions, channel
activity detection, wake-on-radio and charge consumption. The added mode
forwards a given packet at most once per repeater with random backoff.

This is an independent adapter of the flooding logic in the uploaded
LSimSeeded.zip. It is not a byte-for-byte rebuild of that modified simulator
(which has extra mobility, logging, packet visualisation and routing features).
"""

import random
from collections import defaultdict

# Flood-mode parameters introduced to the original simulator.
FLOOD_BACKOFF_MAX_MS = 100.0  # Uniform extra backoff before a relay rebroadcast.
FLOOD_ROUTING_TYPE = 'flood'   # Selects the added forwarding branch.


class FloodingProfile:
    # All added flooding state is stored here to avoid altering the PHY model.
    def __init__(self, sim, backoff_max_ms=FLOOD_BACKOFF_MAX_MS):
        self.sim = sim                        # Original LoRaMSim module.
        self.backoff_max_ms = float(backoff_max_ms)
        self.stats = defaultdict(int)         # Counters for received/forwarded/duplicate packets.
        self.events = []                      # Timestamped transmission/forwarding diagnostics.
        self.installed = False
        if self.backoff_max_ms < 0:
            raise ValueError('backoff_max_ms must be nonnegative')

    def event(self, name, **fields):
        # Store the discrete-event timestamp; not an on-air protocol message.
        self.events.append(dict(time_ms=float(self.sim.env.now), event=name, **fields))

    def flooding_repeat(self, node, env, packet, seq_nr, previous_hop):
        # Forward each DATA_up packet at most once from each available repeater.
        if not getattr(node, 'available', True):
            return
        if seq_nr in node.flood_forwarded or seq_nr in node.flood_pending:
            self.stats['duplicate_suppressed'] += 1
            return

        node.flood_pending.add(seq_nr)         # Cache pending attempt during backoff.
        self.stats['eligible_receptions'] += 1
        try:
            yield env.timeout(random.uniform(0, self.backoff_max_ms))
            if not getattr(node, 'available', True):
                return
            # Let the native simulator arbitrate the local transmitter resource.
            with node.nTransmitters.request() as req:
                yield req
                if not getattr(node, 'available', True):
                    return
                if seq_nr in node.flood_forwarded:
                    return
                node.flood_forwarded.add(seq_nr)   # Mark before transmitting.
                node.nextRp = -1                    # Broadcast rather than fixed next hop.
                self.stats['forwarding_attempts'] += 1
                self.event('forward_attempt', node=node.id, packet_id=seq_nr,
                           previous_hop=previous_hop, algorithm='flood')
                # Native repeat() retains transmission, collision and charge models.
                yield env.process(node.repeat(env, seq_nr, previous_hop))
        finally:
            node.flood_pending.discard(seq_nr)  # Permit receiver to return to idle.

    def install(self):
        # Monkey-patch only extension points, and install before node creation.
        if self.installed:
            return self
        s = self.sim
        if getattr(s, '_flooding_profile_installed', False) or \
                getattr(s, '_opportunistic_profile_installed', False):
            raise RuntimeError('A custom routing profile is already installed')
        original_node_init = s.node.__init__
        original_receive = s.node._receive
        original_has_work = s.node.repeaterHasPendingWork
        profile = self

        def node_init(node, env, x, y, node_type):
            # Initialise the native node, then attach flooding-only state.
            original_node_init(node, env, x, y, node_type)
            node.available = True
            node.flood_forwarded = set()      # Locally forwarded packet IDs.
            node.flood_pending = set()        # Forwarding timers not completed.

        def has_work(node):
            # Keep a sleeping repeater awake during a pending forwarding attempt.
            return bool(node.flood_pending) or original_has_work(node)

        def receive(node, env, packet, seq_nr, previous_distance, next_rp, previous_hop):
            # Intercept upstream DATA only after the native PHY accepted it.
            if node.type.lower() == 'rp' and packet.packetType == 'DATA_up':
                if not node.available:
                    return 0
                if seq_nr in node.flood_forwarded or seq_nr in node.flood_pending:
                    profile.stats['duplicate_suppressed'] += 1
                    return 0
                if seq_nr not in node.recPackets:
                    node.recPackets.append(seq_nr)
                profile.event('relay_receive', node=node.id, packet_id=seq_nr,
                              previous_hop=previous_hop)
                yield env.process(profile.flooding_repeat(
                    node, env, packet, seq_nr, previous_hop))
                return 0
            # Gateway, ED, WOR and downstream follow their original state machines.
            return (yield from original_receive(
                node, env, packet, seq_nr, previous_distance, next_rp,
                previous_hop))

        s.node.__init__ = node_init
        s.node._receive = receive
        s.node.repeaterHasPendingWork = has_work
        s.ROUTING_MODE = FLOOD_ROUTING_TYPE
        s.FLOOD_BACKOFF_MAX_MS = self.backoff_max_ms
        s.FLOOD_STATS = self.stats
        s.FLOOD_EVENTS = self.events
        s._flooding_profile_installed = True
        self.installed = True
        return self


def install_flooding_profile(sim, backoff_max_ms=FLOOD_BACKOFF_MAX_MS):
    # One public entry point. Call before constructing simulator nodes.
    return FloodingProfile(sim, backoff_max_ms).install()
